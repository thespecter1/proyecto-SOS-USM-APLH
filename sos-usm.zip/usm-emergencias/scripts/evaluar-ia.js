// Evaluación del motor de IA sin conexión (app-movil/src/ia/motorIA.js)
// Usa frases que NO forman parte del entrenamiento y mide la exactitud.
// Uso:  node scripts/evaluar-ia.js
const { analizarEmergencia, CLASES } = require("../app-movil/src/ia/motorIA");

const PRUEBAS = [
  ["Sale humo del aula 12 y huele a quemado", "incendio"],
  ["Se prendió en candela la basura detrás del edificio", "incendio"],
  ["Hay llamas en la sala de computación", "incendio"],
  ["Mi compañero dice que le aprieta el pecho y está pálido", "cardiaca"],
  ["Un señor se agarró el pecho y se cayó", "cardiaca"],
  ["La profesora no puede respirar bien, tiene asma", "respiratoria"],
  ["Un niño se atoró con un caramelo", "respiratoria"],
  ["Una muchacha se desmayó en la fila del comedor", "inconsciencia"],
  ["Está convulsionando en el piso del baño", "inconsciencia"],
  ["Un estudiante no responde, está tirado en el jardín", "inconsciencia"],
  ["Me caí en la cancha y creo que me partí la muñeca", "trauma"],
  ["Se cortó la pierna con una lámina y sangra", "trauma"],
  ["Lo chocó una moto en la entrada principal", "trauma"],
  ["Me quemé el brazo con el cautín en el taller", "quemadura"],
  ["Se le cayó agua hirviendo en la mano", "quemadura"],
  ["Comió algo con maní y se le está hinchando la cara", "alergia"],
  ["Lo picaron varias avispas y tiene ronchas", "alergia"],
  ["Hay olor a gas en el cafetín", "gas_quimico"],
  ["Se volcó un envase de ácido en el laboratorio de química", "gas_quimico"],
  ["Se cayó una pared del edificio viejo", "estructural"],
  ["Hay gente atrapada en el ascensor del edificio B", "estructural"],
  ["Un cable está echando chispas cerca del charco", "electrica"],
  ["A un trabajador le dio corriente arreglando el tablero", "electrica"],
  ["Están robando a un estudiante en la parada", "seguridad"],
  ["Dos muchachos se están peleando a golpes", "seguridad"],
  ["Hay un hombre con una pistola en el estacionamiento", "seguridad"],
  ["Me siento muy mareada y con ganas de vomitar", "malestar"],
  ["Tengo fiebre alta desde la mañana", "malestar"],
  ["Una compañera está con un ataque de pánico y no para de llorar", "crisis_emocional"],
  ["Estoy muy nervioso, tengo ansiedad y no me puedo calmar", "crisis_emocional"],
];

let aciertos = 0;
const fallos = [];
const subtipoDe = Object.fromEntries(Object.entries(CLASES).map(([k, c]) => [c.subtipo, k]));
for (const [frase, esperada] of PRUEBAS) {
  const r = analizarEmergencia({ descripcion: frase, rol: "observador" });
  const obtenida = subtipoDe[r.subtipo] || "generico";
  if (obtenida === esperada) aciertos++;
  else fallos.push({ frase, esperada, obtenida, confianza: r.confianza });
}

const exactitud = ((aciertos / PRUEBAS.length) * 100).toFixed(1);
console.log(`\nMotor de IA sin conexión – evaluación con ${PRUEBAS.length} frases nuevas`);
console.log(`Exactitud: ${aciertos}/${PRUEBAS.length} = ${exactitud}%`);
if (fallos.length) {
  console.log("\nFallos:");
  for (const f of fallos) console.log(`  - "${f.frase}" → esperado ${f.esperada}, obtenido ${f.obtenida} (${f.confianza}%)`);
}

// Tiempo de respuesta promedio
const t0 = process.hrtime.bigint();
for (let i = 0; i < 1000; i++) analizarEmergencia({ descripcion: PRUEBAS[i % PRUEBAS.length][0] });
const ms = Number(process.hrtime.bigint() - t0) / 1e6 / 1000;
console.log(`\nTiempo promedio por análisis: ${ms.toFixed(3)} ms (sin internet)\n`);
