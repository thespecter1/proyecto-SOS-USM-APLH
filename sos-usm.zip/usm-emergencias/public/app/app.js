// ============================================================================
//  SOS USM – App móvil de la comunidad universitaria
// ============================================================================
const $ = (s) => document.querySelector(s);
const LS = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
  del: (k) => { try { localStorage.removeItem(k); } catch {} },
};

// Identificador anónimo del dispositivo
let deviceId = LS.get("usm_device");
if (!deviceId) {
  deviceId = (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random()).toString();
  LS.set("usm_device", deviceId);
}

const estado = { ubicacion: null, simulada: false, incidente: null, campus: { lat: 10.4806, lng: -66.804 } };

// ---------------------------------------------------------------------------
//  Navegación
// ---------------------------------------------------------------------------
const PANTALLAS = { permiso: "p-permiso", inicio: "p-inicio", alta: "p-alta", normal: "p-formulario", incidente: "p-incidente" };
function ir(p) {
  document.querySelectorAll(".pantalla").forEach((el) => el.classList.add("oculto"));
  $("#" + PANTALLAS[p]).classList.remove("oculto");
  window.scrollTo(0, 0);
  if (p === "inicio") {
        $("#btn-volver-incidente").classList.toggle("oculto", !estado.incidente || estado.incidente.estado === "resuelto");
  }
  if (p === "alta") { $("#acepto").checked = false; actualizarSOS(); }
  if (p === "normal") {
    const f = $("#formulario");
    if (!f.nombre.value) f.nombre.value = LS.get("usm_nombre") || "";
    if (!f.edad.value) f.edad.value = LS.get("usm_edad") || "";
    const tipo = LS.get("usm_tipo");
    if (tipo && f.querySelector(`[name=tipoUsuario][value="${tipo}"]`)) f.querySelector(`[name=tipoUsuario][value="${tipo}"]`).checked = true;
  }
}
document.querySelectorAll("[data-ir]").forEach((b) => b.addEventListener("click", () => ir(b.dataset.ir)));
$("#btn-normal").addEventListener("click", () => ir("normal"));
$("#btn-alta").addEventListener("click", () => ir("alta"));
$("#btn-volver-incidente").addEventListener("click", () => ir("incidente"));

function toast(t, ms = 3000) {
  const el = $("#toast");
  el.textContent = t;
  el.classList.remove("oculto");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add("oculto"), ms);
}
function vibrar(p) { try { navigator.vibrate && navigator.vibrate(p); } catch {} }
function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

// ---------------------------------------------------------------------------
//  Tiempo real
// ---------------------------------------------------------------------------
const socket = io({ auth: { rol: "usuario", deviceId } });
socket.on("connect", () => {
  if (estado.incidente) socket.emit("incidente:unirse", estado.incidente.id);
  if (estado.ubicacion) socket.emit("ubicacion", estado.ubicacion);
});
socket.on("incidente:actualizado", (inc) => {
  if (estado.incidente && inc.id === estado.incidente.id) {
    const antes = estado.incidente.estado;
    estado.incidente = inc;
    pintarIncidente();
    if (antes !== inc.estado) vibrar([200, 100, 200]);
  }
});
socket.on("chat:mensaje", ({ incidenteId, mensaje }) => {
  if (!estado.incidente || incidenteId !== estado.incidente.id) return;
  if (estado.incidente.mensajes.some((m) => m.id === mensaje.id)) return;
  estado.incidente.mensajes.push(mensaje);
  pintarChat();
  if (mensaje.de === "bomberos") vibrar(120);
});

// ---------------------------------------------------------------------------
//  Geolocalización
// ---------------------------------------------------------------------------
let ultimoEnvio = 0;
function chipGPS(txt, clase) {
  for (const id of ["#chip-gps", "#chip-gps-2"]) {
    $(id).querySelector("span").textContent = txt;
    $(id).className = "chip " + clase;
  }
}
function actualizarUbicacion(u) {
  estado.ubicacion = u;
  chipGPS(estado.simulada ? "Simulada" : `±${Math.round(u.precision || 0)} m`, "ok");
  $("#ubic-texto").textContent = `Ubicación activa · ±${Math.round(u.precision || 0)} m${estado.simulada ? " (simulada)" : ""}`;
  pintarMapa();
  const ahora = Date.now();
  if (ahora - ultimoEnvio > 3000) {
    ultimoEnvio = ahora;
    socket.emit("ubicacion", u);
  }
}

function iniciarGPS() {
  return new Promise((resolve, reject) => {
    if (!("geolocation" in navigator)) return reject(new Error("Tu dispositivo no permite obtener la ubicación."));
    if (!window.isSecureContext) return reject(new Error("La ubicación requiere abrir la app con https:// (ver README)."));
    let primera = true;
    navigator.geolocation.watchPosition(
      (p) => {
        estado.simulada = false;
        actualizarUbicacion({ lat: p.coords.latitude, lng: p.coords.longitude, precision: p.coords.accuracy });
        if (primera) { primera = false; LS.set("usm_gps_ok", "1"); resolve(); }
      },
      (err) => {
        if (primera) {
          primera = false;
          reject(new Error(err.code === 1
            ? "Permiso de ubicación denegado. Actívalo en la configuración del navegador."
            : "No se pudo obtener tu ubicación. Verifica que el GPS esté activo."));
        } else chipGPS("Sin señal", "mal");
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 }
    );
  });
}

function iniciarSimulacion() {
  estado.simulada = true;
  const base = { lat: estado.campus.lat + (Math.random() - 0.5) * 0.0015, lng: estado.campus.lng + (Math.random() - 0.5) * 0.0015 };
  actualizarUbicacion({ ...base, precision: 10 });
  setInterval(() => {
    base.lat += (Math.random() - 0.5) * 0.00008;
    base.lng += (Math.random() - 0.5) * 0.00008;
    actualizarUbicacion({ ...base, precision: 10 });
  }, 5000);
}

$("#btn-permitir").addEventListener("click", async () => {
  const b = $("#btn-permitir");
  b.disabled = true; b.textContent = "Obteniendo ubicación…";
  try {
    await iniciarGPS();
    ir(estado.incidente ? "incidente" : "inicio");
  } catch (e) {
    $("#permiso-error").textContent = e.message;
    $("#permiso-error").classList.remove("oculto");
    $("#btn-simular").classList.remove("oculto");
    b.disabled = false; b.textContent = "Reintentar";
  }
});
$("#btn-simular").addEventListener("click", () => { iniciarSimulacion(); ir(estado.incidente ? "incidente" : "inicio"); });

// ---------------------------------------------------------------------------
//  Mini mapa
// ---------------------------------------------------------------------------
let mapa, marcador, circulo;
function pintarMapa() {
  if (!window.L || !estado.ubicacion || !document.getElementById("mini-mapa")) return;
  const { lat, lng, precision } = estado.ubicacion;
  if (!mapa) {
    mapa = L.map("mini-mapa", { zoomControl: false, attributionControl: false, dragging: false, scrollWheelZoom: false }).setView([lat, lng], 17);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(mapa);
    circulo = L.circle([lat, lng], { radius: precision || 10, color: "#1554d1", weight: 1, fillOpacity: 0.12 }).addTo(mapa);
    marcador = L.circleMarker([lat, lng], { radius: 9, color: "#fff", weight: 3, fillColor: "#1554d1", fillOpacity: 1 }).addTo(mapa);
  } else {
    marcador.setLatLng([lat, lng]);
    circulo.setLatLng([lat, lng]).setRadius(precision || 10);
    mapa.panTo([lat, lng], { animate: true });
  }
}

// ---------------------------------------------------------------------------
//  Reporte normal
// ---------------------------------------------------------------------------
document.querySelectorAll(".sugerencias button").forEach((b) =>
  b.addEventListener("click", () => {
    const t = $("#formulario").descripcion;
    t.value = b.dataset.txt + t.value;
    t.focus();
    t.setSelectionRange(b.dataset.txt.length, b.dataset.txt.length);
  })
);

$("#formulario").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const btn = $("#btn-enviar");
  btn.disabled = true;
  LS.set("usm_nombre", f.nombre.value.trim());
  LS.set("usm_edad", f.edad.value);
  LS.set("usm_tipo", f.tipoUsuario.value);
  try {
    const r = await fetch("/api/incidentes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        deviceId,
        tipoUsuario: f.tipoUsuario.value,
        nombre: f.nombre.value,
        edad: f.edad.value,
        rol: f.rol.value,
        descripcion: f.descripcion.value,
        ubicacion: estado.ubicacion,
      }),
    });
    const datos = await r.json();
    if (!r.ok) throw new Error(datos.error || "No se pudo enviar el reporte.");
    abrirIncidente(datos);
    f.descripcion.value = "";
    vibrar(200);
  } catch (err) {
    toast(err.message || "Sin conexión. Intenta de nuevo.");
  } finally {
    btn.disabled = false;
  }
});

// ---------------------------------------------------------------------------
//  Alerta SOS de alta prioridad (confirmación + mantener 3 s)
// ---------------------------------------------------------------------------
const sos = $("#btn-sos");
function actualizarSOS() {
  sos.disabled = !$("#acepto").checked;
  $("#sos-ayuda").textContent = sos.disabled
    ? "Marca la casilla de confirmación para activar"
    : "Mantén presionado 3 segundos para enviar la alerta";
}
$("#acepto").addEventListener("change", actualizarSOS);

let temporizador = null;
sos.addEventListener("pointerdown", (e) => {
  if (sos.disabled) return;
  e.preventDefault();
  sos.classList.add("presionando");
  $("#sos-ayuda").textContent = "Sigue presionando…";
  vibrar(50);
  temporizador = setTimeout(enviarSOS, 3000);
});
["pointerup", "pointerleave", "pointercancel"].forEach((ev) =>
  sos.addEventListener(ev, () => {
    if (!sos.classList.contains("presionando")) return;
    clearTimeout(temporizador);
    sos.classList.remove("presionando");
    actualizarSOS();
  })
);
sos.addEventListener("contextmenu", (e) => e.preventDefault());

async function enviarSOS() {
  sos.classList.remove("presionando");
  vibrar([300, 100, 300, 100, 600]);
  $("#overlay-sos").classList.remove("oculto");
  try {
    const r = await fetch("/api/panico", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId, ubicacion: estado.ubicacion }),
    });
    const datos = await r.json();
    if (!r.ok) throw new Error(datos.error);
    setTimeout(() => { $("#overlay-sos").classList.add("oculto"); abrirIncidente(datos); }, 2000);
  } catch {
    $("#overlay-sos").classList.add("oculto");
    toast("No se pudo enviar la alerta. Reintentando…");
    setTimeout(enviarSOS, 3000);
  }
}

// ---------------------------------------------------------------------------
//  Emergencia activa
// ---------------------------------------------------------------------------
const ORDEN = ["nuevo", "recibido", "en_camino", "en_sitio", "resuelto"];
const TITULOS = {
  nuevo: ["Alerta enviada", "Esperando confirmación de los Bomberos Universitarios…"],
  recibido: ["Alerta recibida", "Los Bomberos Universitarios están atendiendo tu caso."],
  en_camino: ["Ayuda en camino", "Una unidad se dirige a tu ubicación."],
  en_sitio: ["Unidad en el sitio", "Los bomberos llegaron a tu ubicación."],
  resuelto: ["Emergencia atendida", "El caso fue cerrado por los Bomberos Universitarios."],
};
const SEVERIDAD = { baja: "Baja", moderada: "Moderada", alta: "Alta", critica: "Crítica" };

function abrirIncidente(inc) {
  estado.incidente = inc;
  LS.set("usm_incidente", inc.id);
  socket.emit("incidente:unirse", inc.id);
  pintarIncidente();
  ir("incidente");
}

function pintarIncidente() {
  const inc = estado.incidente;
  if (!inc) return;
  $("#inc-codigo").textContent = inc.tipo === "panico" ? "Alerta SOS" : inc.id;
  const [t, d] = TITULOS[inc.estado] || TITULOS.nuevo;
  $("#estado-titulo").textContent = t;
  $("#estado-detalle").textContent = inc.asignado && inc.estado !== "nuevo" ? `${d} Unidad: ${inc.asignado}` : d;
  $("#estado-tarjeta").className = "estado-hero " + (inc.estado === "resuelto" ? "resuelto" : inc.estado === "nuevo" ? "" : "atendiendo");
  const idx = ORDEN.indexOf(inc.estado);
  document.querySelectorAll("#linea-tiempo li").forEach((li) => li.classList.toggle("hecho", ORDEN.indexOf(li.dataset.e) <= idx));

  const a = inc.analisis;
  if (a) {
    $("#ia-tipo").textContent = a.subtipo;
    $("#ia-sev").textContent = SEVERIDAD[a.severidad] || a.severidad;
    $("#ia-sev").className = "sev " + a.severidad;
    $("#ia-recs").innerHTML = a.recomendaciones.map((r) => `<li><span>${esc(r)}</span></li>`).join("");
    $("#ia-fuente").textContent =
      a.fuente === "claude" ? `Generado por IA · Claude (${a.modelo})`
      : a.fuente === "protocolo" ? "Protocolo automático de alerta SOS"
      : "Análisis preliminar instantáneo · IA local";
  }
  pintarChat();
  $("#btn-nueva").classList.toggle("oculto", inc.estado !== "resuelto");
}

function pintarChat() {
  const c = $("#chat-msgs");
  c.innerHTML = estado.incidente.mensajes.map((m) => {
    const hora = new Date(m.ts).toLocaleTimeString("es-VE", { hour: "2-digit", minute: "2-digit" });
    if (m.de === "sistema") return `<div class="msg sistema">${esc(m.texto)}</div>`;
    const quien = m.de === "bomberos" ? "<b>Bomberos USM</b>" : "";
    return `<div class="msg ${m.de}">${quien}${esc(m.texto)}<small>${hora}</small></div>`;
  }).join("");
  c.scrollTop = c.scrollHeight;
}

$("#chat-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const i = $("#chat-input");
  const texto = i.value.trim();
  if (!texto || !estado.incidente) return;
  socket.emit("chat:enviar", { incidenteId: estado.incidente.id, texto });
  i.value = "";
});

$("#btn-nueva").addEventListener("click", () => {
  estado.incidente = null;
  LS.del("usm_incidente");
  ir("inicio");
});

// ---------------------------------------------------------------------------
//  Arranque
// ---------------------------------------------------------------------------
(async function arrancar() {
  try { estado.campus = (await (await fetch("/api/config")).json()).campus; } catch {}

  const previo = LS.get("usm_incidente");
  if (previo) {
    try {
      const r = await fetch(`/api/incidentes/${previo}?deviceId=${encodeURIComponent(deviceId)}`);
      if (r.ok) {
        const inc = await r.json();
        if (inc.estado !== "resuelto") { estado.incidente = inc; socket.emit("incidente:unirse", inc.id); pintarIncidente(); }
        else LS.del("usm_incidente");
      }
    } catch {}
  }

  let concedido = false;
  try { concedido = (await navigator.permissions.query({ name: "geolocation" })).state === "granted"; }
  catch { concedido = LS.get("usm_gps_ok") === "1"; }

  if (concedido) {
    ir(estado.incidente ? "incidente" : "inicio");
    iniciarGPS().catch((e) => { toast(e.message); ir("permiso"); $("#btn-simular").classList.remove("oculto"); });
  } else ir("permiso");

  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
})();
