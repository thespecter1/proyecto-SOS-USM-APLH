// Service worker mínimo: permite instalar la app (PWA) y cachea la interfaz.
const CACHE = "sos-usm-v2";
const ARCHIVOS = ["/app/", "/app/app.css", "/app/app.js", "/app/icono.svg", "/app/manifest.json"];
self.addEventListener("install", (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARCHIVOS)).then(() => self.skipWaiting())));
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.pathname.startsWith("/api") || url.pathname.startsWith("/socket.io")) return;
  // Red primero, caché como respaldo
  e.respondWith(fetch(e.request).then((r) => {
    if (url.origin === location.origin) { const copia = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copia)); }
    return r;
  }).catch(() => caches.match(e.request)));
});
