// ============================================================================
//  Central de Bomberos Universitarios – panel de supervisión
// ============================================================================
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const hora = (ts) => new Date(ts).toLocaleTimeString("es-VE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const hace = (ts) => {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return `hace ${s}s`;
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`;
  return `hace ${Math.floor(s / 3600)} h`;
};

const ESTADOS = [
  ["recibido", "✋ Acusar recibo"],
  ["en_camino", "🚒 En camino"],
  ["en_sitio", "📍 En sitio"],
  ["resuelto", "✅ Resuelto"],
];
const TXT_ESTADO = { nuevo: "Nuevo", recibido: "Recibido", en_camino: "En camino", en_sitio: "En sitio", resuelto: "Resuelto" };
const CATEGORIA = {
  incendio: "🔥 Incendio", medica: "🩺 Médica", trauma: "🤕 Trauma", fuga_gas_quimico: "☣️ Gas/Químico",
  estructural: "🏚️ Estructural", electrica: "⚡ Eléctrica", seguridad: "🛡️ Seguridad", otro: "❓ Otro",
};
const TIPO_USUARIO = { estudiante: "Estudiante", profesor: "Profesor", administrativo: "Administrativo", seguridad: "Seguridad", limpieza: "Limpieza y mant." };
const RESPUESTAS = [
  "Recibido, vamos en camino.",
  "Mantén la calma, ya tenemos tu ubicación.",
  "¿La persona está consciente y respira?",
  "¿Hay más personas afectadas?",
  "Aléjate del peligro y espera en un lugar visible.",
];

let socket;
let pin = "";
let incidentes = [];
const dispositivos = new Map();
let seleccionado = null;
let vistos = new Set();
let mapa, capaIncidentes, capaDispositivos;
const marcadores = new Map();
const marcadoresDisp = new Map();

// ---------------------------------------------------------------------------
//  Acceso
// ---------------------------------------------------------------------------
$("#form-login").addEventListener("submit", (e) => {
  e.preventDefault();
  pin = $("#pin").value;
  desbloquearAudio();
  conectar();
});
try { const p = sessionStorage.getItem("usm_pin"); if (p) { $("#pin").value = p; } } catch {}

function conectar() {
  socket?.disconnect();
  socket = io({ auth: { rol: "bomberos", pin } });
  socket.on("auth:error", (m) => { $("#login-error").textContent = m; });
  socket.on("connect", () => { $("#conexion").textContent = "● En línea"; $("#conexion").className = "chip ok"; });
  socket.on("disconnect", () => { $("#conexion").textContent = "● Desconectado"; $("#conexion").className = "chip mal"; });

  socket.on("auth:ok", (datos) => {
    try { sessionStorage.setItem("usm_pin", pin); } catch {}
    $("#login").classList.add("oculto");
    incidentes = datos.incidentes;
    incidentes.forEach((i) => vistos.add(i.id));
    datos.dispositivos.forEach((d) => dispositivos.set(d.id, d));
    iniciarMapa();
    renderTodo();
  });

  socket.on("incidente:nuevo", (inc) => {
    incidentes = incidentes.filter((i) => i.id !== inc.id);
    incidentes.unshift(inc);
    renderTodo();
    if (inc.tipo === "panico" || (inc.analisis?.prioridad || 0) >= 4) alarma(inc);
    else pitido();
    notificar(inc);
  });
  socket.on("alarma:panico", ({ id }) => { const inc = incidentes.find((i) => i.id === id); if (inc) { alarma(inc); seleccionar(id, true); } });

  socket.on("incidente:actualizado", (inc) => {
    const i = incidentes.findIndex((x) => x.id === inc.id);
    const prioAntes = i >= 0 ? incidentes[i].analisis?.prioridad : null;
    if (i >= 0) incidentes[i] = inc; else incidentes.unshift(inc);
    // Si la IA eleva la prioridad a crítica, sonar alarma
    if (inc.estado === "nuevo" && (inc.analisis?.prioridad || 0) >= 4 && (prioAntes || 0) < 4) alarma(inc);
    renderTodo();
  });

  socket.on("incidente:ubicacion", ({ id, ubicacion }) => {
    const inc = incidentes.find((i) => i.id === id);
    if (!inc) return;
    inc.ubicacion = ubicacion;
    (inc.recorrido ||= []).push(ubicacion);
    renderMapa();
    if (seleccionado === id) renderUbicacionDetalle(inc);
  });

  socket.on("chat:mensaje", ({ incidenteId, mensaje }) => {
    const inc = incidentes.find((i) => i.id === incidenteId);
    if (!inc || inc.mensajes.some((m) => m.id === mensaje.id)) return;
    inc.mensajes.push(mensaje);
    if (mensaje.de === "usuario") {
      pitido();
      if (seleccionado !== incidenteId) inc._sinLeer = true;
    }
    if (seleccionado === incidenteId) renderChat(inc);
    renderLista();
  });

  socket.on("dispositivo:ubicacion", ({ id, ubicacion }) => {
    dispositivos.set(id, { ...(dispositivos.get(id) || {}), id, ubicacion, conectado: true });
    renderDispositivos();
  });
  socket.on("dispositivo:desconectado", ({ id }) => {
    const d = dispositivos.get(id);
    if (d) d.conectado = false;
    renderDispositivos();
  });

  fetch("/api/config").then((r) => r.json()).then((c) => {
    window.CAMPUS = c.campus;
    $("#ia-estado").textContent = c.ia.remota ? `🤖 IA: Claude` : "🤖 IA: local";
    $("#ia-estado").className = "chip ok";
    $("#ia-estado").title = c.ia.modelo;
  });
}

// ---------------------------------------------------------------------------
//  Mapa
// ---------------------------------------------------------------------------
function iniciarMapa() {
  if (mapa || !window.L) return;
  const c = window.CAMPUS || { lat: 10.4806, lng: -66.804 };
  mapa = L.map("mapa").setView([c.lat, c.lng], 17);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19, attribution: "© OpenStreetMap",
  }).addTo(mapa);
  L.marker([c.lat, c.lng], {
    icon: L.divIcon({ className: "", html: '<div style="font-size:26px">🏫</div>', iconSize: [30, 30], iconAnchor: [15, 15] }),
  }).addTo(mapa).bindTooltip("Universidad Santa María");
  capaDispositivos = L.layerGroup().addTo(mapa);
  capaIncidentes = L.layerGroup().addTo(mapa);
}

function claseIncidente(inc) {
  const p = inc.analisis?.prioridad || 3;
  return `p${p} ${inc.tipo === "panico" && inc.estado !== "resuelto" ? "panico" : ""} ${inc.estado === "resuelto" ? "resuelto" : ""}`;
}

let rutaSel = null;
function renderMapa() {
  if (!mapa) return;
  const visibles = new Set();
  for (const inc of incidentes) {
    if (!inc.ubicacion || (inc.estado === "resuelto" && inc.id !== seleccionado)) continue;
    visibles.add(inc.id);
    const pos = [inc.ubicacion.lat, inc.ubicacion.lng];
    const icono = L.divIcon({ className: "", html: `<div class="mk ${claseIncidente(inc)}"></div>`, iconSize: [22, 22], iconAnchor: [11, 11] });
    let m = marcadores.get(inc.id);
    if (!m) {
      m = L.marker(pos, { icon: icono, zIndexOffset: 1000 }).addTo(capaIncidentes);
      m.on("click", () => seleccionar(inc.id));
      marcadores.set(inc.id, m);
    } else {
      m.setLatLng(pos).setIcon(icono);
    }
    m.bindTooltip(`${inc.tipo === "panico" ? "ALERTA SOS" : esc(inc.analisis?.subtipo || "Emergencia")} · ${TXT_ESTADO[inc.estado]}`);
  }
  for (const [id, m] of marcadores) if (!visibles.has(id)) { capaIncidentes.removeLayer(m); marcadores.delete(id); }

  // Recorrido del incidente seleccionado
  if (rutaSel) { mapa.removeLayer(rutaSel); rutaSel = null; }
  const sel = incidentes.find((i) => i.id === seleccionado);
  if (sel?.recorrido?.length > 1) {
    rutaSel = L.polyline(sel.recorrido.map((u) => [u.lat, u.lng]), { color: "#7aa2ff", weight: 3, dashArray: "4 6" }).addTo(mapa);
  }
}

function renderDispositivos() {
  if (!mapa) return;
  let enLinea = 0;
  for (const [id, d] of dispositivos) {
    if (!d.ubicacion || !d.conectado) {
      if (marcadoresDisp.has(id)) { capaDispositivos.removeLayer(marcadoresDisp.get(id)); marcadoresDisp.delete(id); }
      continue;
    }
    enLinea++;
    const pos = [d.ubicacion.lat, d.ubicacion.lng];
    let m = marcadoresDisp.get(id);
    if (!m) {
      m = L.circleMarker(pos, { radius: 5, color: "#7aa2ff", weight: 2, fillColor: "#7aa2ff", fillOpacity: 0.6 }).addTo(capaDispositivos).bindTooltip("Usuario de la app (en línea)");
      marcadoresDisp.set(id, m);
    } else m.setLatLng(pos);
  }
  $("#k-usuarios").textContent = enLinea;
}

// ---------------------------------------------------------------------------
//  Lista
// ---------------------------------------------------------------------------
function ordenar(a, b) {
  const ra = a.estado === "resuelto" ? 1 : 0, rb = b.estado === "resuelto" ? 1 : 0;
  if (ra !== rb) return ra - rb;
  const pa = a.analisis?.prioridad || 0, pb = b.analisis?.prioridad || 0;
  if (pa !== pb) return pb - pa;
  return b.creadoEn - a.creadoEn;
}

function renderLista() {
  const filtro = $("#filtro").value;
  const lista = incidentes
    .filter((i) => filtro === "todas" || (filtro === "activas" ? i.estado !== "resuelto" : i.estado === "resuelto"))
    .sort(ordenar);
  $("#lista-incidentes").innerHTML = lista.length
    ? lista.map((i) => {
        const p = i.analisis?.prioridad || "…";
        const titulo = i.tipo === "panico" ? "🚨 ALERTA SOS" : esc(i.analisis?.subtipo || "Analizando…");
        const quien = i.reportante
          ? i.reportante.rol === "observador" && i.afectado?.conocido
            ? `Afectado: ${esc(i.afectado.nombre)}${i.perfilAfectado ? " · ficha encontrada" : ""} · reporta ${esc(i.reportante.nombre)}`
            : i.reportante.rol === "observador"
              ? `Afectado desconocido · reporta ${esc(i.reportante.nombre)}`
              : `${esc(i.reportante.nombre)} · ${TIPO_USUARIO[i.reportante.tipoUsuario] || "Comunidad USM"} · afectado`
          : i.perfil ? `${esc(i.perfil.nombre)} · ${TIPO_USUARIO[i.perfil.tipoUsuario] || "Comunidad USM"} · ficha registrada` : "Sin datos (alerta SOS)";
        return `<div class="item ${claseIncidente(i)} ${i.id === seleccionado ? "sel" : ""}" data-id="${i.id}">
          <div class="fila"><span class="tipo">${titulo}</span><span class="prio p${p}">P${p}</span></div>
          <div class="meta">${quien}</div>
          <div class="fila meta"><span class="est">${TXT_ESTADO[i.estado]}</span>
            <span>${i.estado === "nuevo" ? '<span class="nuevo-badge">SIN ATENDER</span> ' : ""}${i._sinLeer ? "💬 " : ""}${hace(i.creadoEn)}</span></div>
        </div>`;
      }).join("")
    : '<div class="vacio-lista">No hay emergencias en esta vista.<br/>Todo en calma ✅</div>';
}
$("#lista-incidentes").addEventListener("click", (e) => {
  const it = e.target.closest(".item");
  if (it) seleccionar(it.dataset.id, true);
});
$("#filtro").addEventListener("change", renderLista);

function renderKpis() {
  const activos = incidentes.filter((i) => i.estado !== "resuelto");
  $("#k-activos").textContent = activos.length;
  $("#k-criticos").textContent = activos.filter((i) => (i.analisis?.prioridad || 0) >= 5).length;
  $("#k-total").textContent = incidentes.length;
  const pendientesPanico = activos.some((i) => i.tipo === "panico" && i.estado === "nuevo");
  $("#banner-panico").classList.toggle("oculto", !pendientesPanico);
  if (!activos.some((i) => i.estado === "nuevo" && ((i.analisis?.prioridad || 0) >= 4 || i.tipo === "panico"))) detenerAlarma();
  document.title = (activos.filter((i) => i.estado === "nuevo").length ? `(${activos.filter((i) => i.estado === "nuevo").length}) ` : "") + "Central SOS USM";
}

function renderTodo() {
  renderKpis();
  renderLista();
  renderMapa();
  renderDispositivos();
  if (seleccionado) renderDetalle();
}

// ---------------------------------------------------------------------------
//  Detalle
// ---------------------------------------------------------------------------
function seleccionar(id, centrar) {
  seleccionado = id;
  const inc = incidentes.find((i) => i.id === id);
  if (inc) inc._sinLeer = false;
  renderLista();
  renderMapa();
  renderDetalle(true);
  if (centrar && inc?.ubicacion && mapa) mapa.setView([inc.ubicacion.lat, inc.ubicacion.lng], 18, { animate: true });
}

function renderDetalle(desdeCero) {
  const inc = incidentes.find((i) => i.id === seleccionado);
  const cont = $("#detalle");
  if (!inc) { cont.className = "detalle vacio"; cont.innerHTML = '<div class="vacio-txt">Selecciona una emergencia.</div>'; return; }

  // Conservar lo que el bombero está escribiendo
  const entrada = $("#chat-entrada");
  const borrador = desdeCero ? "" : entrada?.value || "";
  const conFoco = !desdeCero && document.activeElement === entrada;
  const unidadPrev = desdeCero ? undefined : $("#unidad")?.value;

  const a = inc.analisis;
  const r = inc.reportante;
  cont.className = "detalle";
  cont.innerHTML = `<div class="det">
    <div>
      <div class="fila" style="display:flex;justify-content:space-between;align-items:center;gap:8px">
        <h2>${inc.tipo === "panico" ? "🚨 ALERTA SOS" : esc(a?.subtipo || "Analizando…")}</h2>
        <span class="prio p${a?.prioridad || 3}">P${a?.prioridad || "…"}</span>
      </div>
      <div class="cod">${inc.id} · ${hora(inc.creadoEn)} · ${hace(inc.creadoEn)}</div>
    </div>

    <div class="bloque">
      <h4>Estado: ${TXT_ESTADO[inc.estado]}${inc.asignado ? " · " + esc(inc.asignado) : ""}</h4>
      <div class="estados">
        ${ESTADOS.map(([e, t]) => `<button class="btn ${inc.estado === e ? "activo" : ""} ${e === "resuelto" ? "fin" : ""}" data-estado="${e}">${t}</button>`).join("")}
      </div>
      <div class="unidad"><input id="unidad" placeholder="Unidad asignada (ej. Unidad B-1)" value="${esc(unidadPrev ?? inc.asignado ?? "")}" /></div>
    </div>

    <div class="bloque">
      <h4>Reportante</h4>
      ${r ? `<dl class="datos">
          <dt>Nombre</dt><dd>${esc(r.nombre)}</dd>
          <dt>Comunidad</dt><dd>${TIPO_USUARIO[r.tipoUsuario] || "—"}</dd>
          <dt>Edad</dt><dd>${r.edad ?? "—"}</dd>
          <dt>Rol</dt><dd>${r.rol === "observador" ? "👀 Observador" : "🙋 Afectado"}</dd>
        </dl>
        <h4 style="margin-top:10px">Descripción</h4>
        <p class="desc">“${esc(inc.descripcion)}”</p>`
      : inc.perfil ? `<p class="desc">Alerta SOS enviada por una persona registrada. Su ficha aparece abajo.</p>`
      : `<p class="desc">Alerta SOS de una persona sin registro. Acudir a la ubicación GPS de inmediato.</p>`}
    </div>

    ${afectadoHTML(inc)}
    ${fichaHTML(inc.perfil, inc.reportante?.rol === "observador" ? "Ficha de quien reporta (observador)" : "Ficha registrada")}

    <div class="bloque" id="bloque-ubic"></div>

    ${a ? `<div class="bloque">
      <h4>🤖 Análisis de IA · ${CATEGORIA[a.categoria] || a.categoria} · Severidad ${esc(a.severidad)}</h4>
      <p class="ia-resumen">${esc(a.resumen)}</p>
      <h4>Recomendaciones enviadas al usuario</h4>
      <ol class="ia-lista">${a.recomendaciones.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>
      <div class="recursos">${(a.recursos || []).map((x) => `<span>${esc(x)}</span>`).join("")}</div>
      <small class="fuente">${a.fuente === "claude" ? "Generado por Claude (" + esc(a.modelo) + ")" : a.fuente === "protocolo" ? "Protocolo automático" : "Clasificador local (preliminar)"} · ${hora(a.ts)}</small>
    </div>` : ""}

    <div class="bloque">
      <h4>💬 Chat con el usuario</h4>
      <div class="chat-msgs" id="chat-msgs"></div>
      <div class="rapidas">${RESPUESTAS.map((t) => `<button data-rapida="${esc(t)}">${esc(t)}</button>`).join("")}</div>
      <form class="chat-form" id="chat-form">
        <input id="chat-entrada" placeholder="Escribe al usuario…" autocomplete="off" maxlength="1000" />
        <button class="btn rojo">Enviar</button>
      </form>
    </div>
  </div>`;

  renderUbicacionDetalle(inc);
  renderChat(inc);
  const nueva = $("#chat-entrada");
  nueva.value = borrador;
  if (conFoco) nueva.focus();

  cont.querySelectorAll("[data-estado]").forEach((b) =>
    b.addEventListener("click", () => socket.emit("incidente:estado", { id: inc.id, estado: b.dataset.estado, unidad: $("#unidad").value.trim() || undefined }))
  );
  cont.querySelectorAll("[data-rapida]").forEach((b) => b.addEventListener("click", () => enviarChat(inc.id, b.dataset.rapida)));
  $("#chat-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const t = $("#chat-entrada").value.trim();
    if (t) { enviarChat(inc.id, t); $("#chat-entrada").value = ""; }
  });
  if (desdeCero) cont.scrollTop = 0;
}

// Ficha registrada por una persona en un momento de calma
function fichaHTML(p, titulo, nota) {
  if (!p) return "";
  const fila = (t, v, destacado) => (v ? `<dt>${t}</dt><dd${destacado ? ' class="alerta-medica"' : ""}>${esc(v)}</dd>` : "");
  const medica = fila("Sangre", p.sangre && p.sangre !== "No sé" ? p.sangre : "") + fila("Condiciones", p.condiciones, true) +
    fila("Alergias", p.alergias, true) + fila("Medicamentos", p.medicamentos);
  return `<div class="bloque ficha">
      <h4>🪪 ${titulo}</h4>
      ${nota ? `<p class="nota-ficha">${nota}</p>` : ""}
      <dl class="datos">
        ${fila("Nombre", p.nombre)}${fila("Cédula", p.cedula)}
        ${fila("Comunidad", TIPO_USUARIO[p.tipoUsuario])}${fila("Edad", p.edad ? p.edad + " años" : "")}
        ${fila("Carrera/área", p.carrera)}${fila("Teléfono", p.telefono)}
      </dl>
      <h4 style="margin-top:10px">Información médica</h4>
      ${medica ? `<dl class="datos">${medica}</dl>` : '<p class="desc">No declaró información médica.</p>'}
      ${p.contactoNombre || p.contactoTelefono ? `<h4 style="margin-top:10px">Contacto de emergencia</h4>
      <dl class="datos">${fila("Nombre", p.contactoNombre)}${fila("Parentesco", p.contactoParentesco)}${fila("Teléfono", p.contactoTelefono)}</dl>` : ""}
    </div>`;
}

// Persona afectada según el observador, y su ficha si se encontró en la base de datos
function afectadoHTML(inc) {
  const a = inc.afectado;
  if (!a) return "";
  if (!a.conocido) {
    return `<div class="bloque"><h4>Persona afectada</h4><p class="desc">El observador no conoce a la persona afectada.</p></div>`;
  }
  const c = inc.coincidencia || {};
  const datos = `<dl class="datos"><dt>Nombre</dt><dd>${esc(a.nombre) || "—"}</dd><dt>Edad</dt><dd>${a.edad ?? "—"}</dd><dt>Cédula</dt><dd>${esc(a.cedula) || "—"}</dd></dl>`;
  if (c.estado === "encontrado" && inc.perfilAfectado) {
    const nota = c.nivel === "alta"
      ? "✅ Coincidencia por <b>cédula</b> (confianza alta)."
      : "⚠️ Coincidencia por <b>nombre y edad</b> (confianza media): verificar la identidad en el sitio.";
    return `<div class="bloque"><h4>Persona afectada (según el observador)</h4>${datos}</div>` +
      fichaHTML(inc.perfilAfectado, "Ficha registrada del afectado", nota);
  }
  const motivo = {
    ambiguo: `Varias personas registradas coinciden (${c.total}); no se adjuntó ninguna ficha para evitar errores.`,
    insuficiente: "Datos insuficientes para buscar su registro (se necesita nombre y apellido con edad, o la cédula).",
    no_encontrado: "No se encontró un registro con esos datos.",
  }[c.estado] || "";
  return `<div class="bloque"><h4>Persona afectada (según el observador)</h4>${datos}<p class="desc">${motivo}</p></div>`;
}

function renderUbicacionDetalle(inc) {
  const b = $("#bloque-ubic");
  if (!b) return;
  const u = inc.ubicacion;
  b.innerHTML = `<h4>📍 Ubicación en tiempo real</h4>${u
    ? `<dl class="datos"><dt>Coordenadas</dt><dd>${u.lat.toFixed(6)}, ${u.lng.toFixed(6)}</dd>
       <dt>Precisión</dt><dd>±${Math.round(u.precision || 0)} m</dd>
       <dt>Actualizada</dt><dd>${hora(u.ts || inc.creadoEn)}</dd></dl>
       <div style="margin-top:8px;display:flex;gap:6px">
         <button class="btn" id="btn-centrar">Centrar en mapa</button>
         <a class="btn" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${u.lat},${u.lng}">Ruta (Google Maps)</a>
       </div>`
    : '<p class="desc">El dispositivo no compartió ubicación.</p>'}`;
  $("#btn-centrar")?.addEventListener("click", () => mapa.setView([u.lat, u.lng], 18));
}

function renderChat(inc) {
  const c = $("#chat-msgs");
  if (!c) return;
  c.innerHTML = inc.mensajes.map((m) =>
    m.de === "sistema"
      ? `<div class="msg sistema">${esc(m.texto)}</div>`
      : `<div class="msg ${m.de}">${esc(m.texto)}<small>${m.de === "usuario" ? "Usuario" : "Central"} · ${hora(m.ts)}</small></div>`
  ).join("");
  c.scrollTop = c.scrollHeight;
}

function enviarChat(incidenteId, texto) {
  socket.emit("chat:enviar", { incidenteId, texto });
}

// ---------------------------------------------------------------------------
//  Alarmas sonoras y notificaciones
// ---------------------------------------------------------------------------
let ctx, sirena = null;
function desbloquearAudio() {
  try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); ctx.resume(); } catch {}
  if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
}
function pitido() {
  if (!ctx) return;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.frequency.value = 880; g.gain.value = 0.08;
  o.connect(g).connect(ctx.destination);
  o.start(); o.stop(ctx.currentTime + 0.18);
}
function alarma(inc) {
  $("#btn-silenciar").classList.remove("oculto");
  if (!ctx || sirena) return;
  const o = ctx.createOscillator(), g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain();
  o.type = "sawtooth"; o.frequency.value = 750; g.gain.value = 0.06;
  lfo.frequency.value = 1.5; lg.gain.value = 300;
  lfo.connect(lg).connect(o.frequency);
  o.connect(g).connect(ctx.destination);
  o.start(); lfo.start();
  sirena = { o, lfo };
  setTimeout(detenerAlarma, 30000); // autosilencio a los 30 s
}
function detenerAlarma() {
  if (sirena) { try { sirena.o.stop(); sirena.lfo.stop(); } catch {} sirena = null; }
  $("#btn-silenciar").classList.add("oculto");
}
$("#btn-silenciar").addEventListener("click", detenerAlarma);

function notificar(inc) {
  if (!("Notification" in window) || Notification.permission !== "granted" || document.hasFocus()) return;
  const n = new Notification(inc.tipo === "panico" ? "🚨 ALERTA SOS" : "Nueva emergencia", {
    body: inc.tipo === "panico" ? "Máxima prioridad. Ver ubicación." : `${inc.reportante?.nombre}: ${inc.descripcion.slice(0, 80)}`,
    requireInteraction: inc.tipo === "panico",
  });
  n.onclick = () => { window.focus(); seleccionar(inc.id, true); };
}

// Refrescar los "hace X min"
setInterval(() => { if (incidentes.length) renderLista(); }, 15000);
