// Componentes visuales compartidos
import { Pressable, StyleSheet, Text, View, ActivityIndicator } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono, { Logo } from "./Icono";
import { C, F } from "../tema";
import { useSOS } from "../estado/SOSContext";

export function Cabecera({ titulo, atras, derecha }) {
  const insets = useSafeAreaInsets();
  const volver = () => (router.canGoBack() ? router.back() : router.replace("/inicio"));
  return (
    <LinearGradient
      colors={[C.azul800, C.azul600]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[e.cabecera, { paddingTop: insets.top + 12 }]}
    >
      {atras ? (
        <Pressable onPress={volver} style={e.atras} accessibilityRole="button" accessibilityLabel="Volver">
          <Icono nombre="atras" color="#fff" />
        </Pressable>
      ) : (
        <View style={e.marca}>
          <View style={e.logoMarco}><Logo tamano={30} /></View>
          {!titulo ? <Text style={e.marcaTexto}>SOS USM</Text> : null}
        </View>
      )}
      {titulo ? <Text style={e.titulo} numberOfLines={1}>{titulo}</Text> : null}
      {derecha ?? <View style={{ width: atras ? 38 : 34 }} />}
    </LinearGradient>
  );
}

export function ChipGPS({ texto }) {
  const { ubicacion, simulada } = useSOS();
  const t = texto ?? (ubicacion ? (simulada ? "Simulada" : `±${Math.round(ubicacion.precision ?? 0)} m`) : "Buscando…");
  return (
    <View style={e.chip}>
      <Icono nombre="pin" tamano={14} color={C.azul700} />
      <Text style={e.chipTexto}>{t}</Text>
    </View>
  );
}

export function BotonPrimario({ texto, onPress, cargando, icono, deshabilitado }) {
  return (
    <Pressable onPress={onPress} disabled={cargando || deshabilitado} accessibilityRole="button" style={({ pressed }) => [{ opacity: deshabilitado ? 0.6 : 1, transform: [{ scale: pressed ? 0.99 : 1 }] }]}>
      <LinearGradient colors={[C.azul600, C.azul700]} style={e.primario}>
        {cargando ? <ActivityIndicator color="#fff" /> : (
          <>
            <Text style={e.primarioTexto}>{texto}</Text>
            {icono ? <Icono nombre={icono} color="#fff" tamano={18} /> : null}
          </>
        )}
      </LinearGradient>
    </Pressable>
  );
}

export function BotonEnlace({ texto, onPress }) {
  return (
    <Pressable onPress={onPress} style={{ padding: 10, alignItems: "center" }} accessibilityRole="button">
      <Text style={e.enlace}>{texto}</Text>
    </Pressable>
  );
}

const e = StyleSheet.create({
  cabecera: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, paddingHorizontal: 16, paddingBottom: 14 },
  marca: { flexDirection: "row", alignItems: "center", gap: 10 },
  logoMarco: { borderRadius: 9, overflow: "hidden", borderWidth: 2, borderColor: "rgba(255,255,255,0.35)" },
  marcaTexto: { color: "#fff", fontFamily: F.extra, fontSize: 18 },
  titulo: { flex: 1, textAlign: "center", color: "#fff", fontFamily: F.negrita, fontSize: 16 },
  atras: { width: 38, height: 38, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.16)", alignItems: "center", justifyContent: "center" },
  chip: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#fff", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999 },
  chipTexto: { color: C.azul700, fontFamily: F.negrita, fontSize: 12 },
  primario: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 14, paddingVertical: 15, paddingHorizontal: 18, boxShadow: "0px 6px 16px rgba(21, 84, 209, 0.30)" },
  primarioTexto: { color: "#fff", fontFamily: F.negrita, fontSize: 16 },
  enlace: { color: C.azul600, fontFamily: F.semi, fontSize: 14 },
});
