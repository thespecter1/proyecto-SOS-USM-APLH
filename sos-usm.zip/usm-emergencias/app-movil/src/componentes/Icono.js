import Svg, { Path, Circle, Rect, Text as SvgText } from "react-native-svg";

const trazo = { fill: "none", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };

const ICONOS = {
  pin: (c) => (<><Path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z" stroke={c} {...trazo} /><Circle cx="12" cy="10" r="2.6" stroke={c} {...trazo} /></>),
  ia: (c) => (<Path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z M19 15l.9 2.1 2.1.9-2.1.9L19 21l-.9-2.1-2.1-.9 2.1-.9z" fill={c} />),
  chat: (c) => (<Path d="M4 5h16v11H9l-5 4z" stroke={c} {...trazo} />),
  alerta: (c) => (<><Path d="M12 3l10 18H2z" stroke={c} {...trazo} /><Path d="M12 10v5" stroke={c} {...trazo} /><Circle cx="12" cy="18" r="1.2" fill={c} /></>),
  documento: (c) => (<><Path d="M6 3h9l4 4v14H6z" stroke={c} {...trazo} /><Path d="M9 12h7M9 16h5" stroke={c} {...trazo} /></>),
  flecha: (c) => (<Path d="M9 6l6 6-6 6" stroke={c} {...trazo} strokeWidth={2.4} />),
  atras: (c) => (<Path d="M15 6l-6 6 6 6" stroke={c} {...trazo} strokeWidth={2.4} />),
  enviar: (c) => (<Path d="M4 12l16-8-6 16-2.5-6.5z" stroke={c} {...trazo} />),
  check: (c) => (<Path d="M5 12.5l4.5 4.5L19 7.5" stroke={c} {...trazo} strokeWidth={2.8} />),
  usuario: (c) => (<><Circle cx="12" cy="8" r="4" stroke={c} {...trazo} /><Path d="M4 21c1.2-4 4.3-6 8-6s6.8 2 8 6" stroke={c} {...trazo} /></>),
  corazon: (c) => (<Path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" stroke={c} {...trazo} />),
  telefono: (c) => (<Path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z" stroke={c} {...trazo} />),
  escudo: (c) => (<><Path d="M12 3l8 3v6c0 4.6-3.4 8.4-8 9-4.6-.6-8-4.4-8-9V6z" stroke={c} {...trazo} /><Path d="M9 12l2 2 4-4" stroke={c} {...trazo} /></>),
};

export default function Icono({ nombre, tamano = 20, color = "#000" }) {
  return (
    <Svg width={tamano} height={tamano} viewBox="0 0 24 24">
      {ICONOS[nombre](color)}
    </Svg>
  );
}

export function Logo({ tamano = 32 }) {
  return (
    <Svg width={tamano} height={tamano} viewBox="0 0 512 512">
      <Rect width="512" height="512" rx="116" fill="#1554d1" />
      <Path d="M256 84l150 56v108c0 92-63 166-150 186-87-20-150-94-150-186V140z" fill="#ffffff" />
      <SvgText x="256" y="318" textAnchor="middle" fontWeight="900" fontSize="118" fill="#0f3c9e">SOS</SvgText>
    </Svg>
  );
}
