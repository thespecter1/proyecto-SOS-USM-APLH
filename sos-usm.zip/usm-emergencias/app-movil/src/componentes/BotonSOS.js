// Botón SOS: hay que mantenerlo presionado (3 s por defecto) para evitar envíos accidentales.
import { useMemo, useRef, useState } from "react";
import { Animated, Easing, Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import Svg, { Circle } from "react-native-svg";
import { C, F } from "../tema";
import { vibrar } from "../estado/SOSContext";

const CirculoAnimado = Animated.createAnimatedComponent(Circle);

export default function BotonSOS({ deshabilitado, onCompletado, onEstado, duracion = 3000, tamano = 116 }) {
  const [progreso] = useState(() => new Animated.Value(0));
  const animacion = useRef(null);
  const [presionando, setPresionando] = useState(false);

  const centro = tamano / 2;
  const radio = centro - 5;
  const circunferencia = 2 * Math.PI * radio;
  const desfase = useMemo(
    () => progreso.interpolate({ inputRange: [0, 1], outputRange: [circunferencia, 0] }),
    [progreso, circunferencia]
  );

  const iniciar = () => {
    if (deshabilitado) return;
    setPresionando(true);
    onEstado?.(true);
    vibrar("ligero");
    animacion.current = Animated.timing(progreso, { toValue: 1, duration: duracion, easing: Easing.linear, useNativeDriver: false });
    animacion.current.start(({ finished }) => {
      setPresionando(false);
      onEstado?.(false);
      progreso.setValue(0);
      animacion.current = null;
      if (finished) onCompletado?.();
    });
  };
  const cancelar = () => animacion.current?.stop();

  return (
    <View style={[e.halo, { borderRadius: tamano }, deshabilitado && { backgroundColor: "transparent" }]}>
      <Pressable
        onPressIn={iniciar}
        onPressOut={cancelar}
        disabled={deshabilitado}
        accessibilityRole="button"
        accessibilityLabel="Enviar alerta SOS: mantén presionado 3 segundos"
        accessibilityState={{ disabled: deshabilitado }}
      >
        <View style={{ width: tamano, height: tamano, borderRadius: tamano / 2, overflow: "hidden", opacity: deshabilitado ? 0.45 : 1, transform: [{ scale: presionando ? 0.96 : 1 }] }}>
          <LinearGradient
            colors={deshabilitado ? ["#b9bec9", "#8e94a3"] : ["#f6636d", C.peligro, C.peligroOscuro]}
            start={{ x: 0.2, y: 0.1 }}
            end={{ x: 0.9, y: 1 }}
            style={e.relleno}
          >
            <Text style={[e.texto, { fontSize: tamano * 0.26 }]}>SOS</Text>
          </LinearGradient>
          <Svg width={tamano} height={tamano} style={StyleSheet.absoluteFill} pointerEvents="none">
            <CirculoAnimado
              cx={centro}
              cy={centro}
              r={radio}
              stroke="#ffffff"
              strokeWidth={6}
              strokeLinecap="round"
              fill="none"
              strokeDasharray={`${circunferencia} ${circunferencia}`}
              strokeDashoffset={desfase}
              transform={`rotate(-90 ${centro} ${centro})`}
            />
          </Svg>
        </View>
      </Pressable>
    </View>
  );
}

const e = StyleSheet.create({
  halo: { padding: 8, backgroundColor: "rgba(217, 45, 58, 0.12)" },
  relleno: { flex: 1, alignItems: "center", justifyContent: "center" },
  texto: { color: "#fff", fontFamily: F.extra, letterSpacing: 2 },
});
