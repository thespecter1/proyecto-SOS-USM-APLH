// Contacto directo con la central cuando no hay internet: llamada telefónica y SMS
// con la ubicación GPS. Ambos usan la red telefónica, no los datos móviles.
import { Linking, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import Icono from "./Icono";
import { useSOS } from "../estado/SOSContext";
import { C, F, TELEFONO_BOMBEROS } from "../tema";

export default function ContactoDirecto({ tipo = "emergencia" }) {
  const { ubicacion, perfil } = useSOS();
  if (!TELEFONO_BOMBEROS) return null;

  const llamar = () => Linking.openURL(`tel:${TELEFONO_BOMBEROS}`).catch(() => {});

  const enviarSMS = () => {
    const partes = [`SOS USM: ${tipo === "sos" ? "ALERTA DE ALTA PRIORIDAD" : "emergencia"}.`];
    if (perfil.registrado) partes.push(`${perfil.nombre}, C.I. ${perfil.cedula}${perfil.sangre && perfil.sangre !== "No sé" ? `, sangre ${perfil.sangre}` : ""}.`);
    if (ubicacion) partes.push(`Ubicación: https://maps.google.com/?q=${ubicacion.lat.toFixed(6)},${ubicacion.lng.toFixed(6)}`);
    const cuerpo = encodeURIComponent(partes.join(" "));
    const separador = Platform.OS === "ios" ? "&" : "?";
    Linking.openURL(`sms:${TELEFONO_BOMBEROS}${separador}body=${cuerpo}`).catch(() => {});
  };

  return (
    <View style={e.caja}>
      <Text style={e.titulo}>Contacto directo sin internet</Text>
      <Text style={e.texto}>Las llamadas y los SMS funcionan con la señal telefónica, aunque no tengas datos.</Text>
      <View style={e.fila}>
        <Pressable onPress={llamar} style={[e.boton, { backgroundColor: C.azul600 }]} accessibilityRole="button">
          <Icono nombre="telefono" tamano={18} color="#fff" />
          <Text style={e.botonTexto}>Llamar</Text>
        </Pressable>
        <Pressable onPress={enviarSMS} style={[e.boton, { backgroundColor: C.azul800 }]} accessibilityRole="button">
          <Icono nombre="chat" tamano={18} color="#fff" />
          <Text style={e.botonTexto}>SMS con ubicación</Text>
        </Pressable>
      </View>
    </View>
  );
}

const e = StyleSheet.create({
  caja: { backgroundColor: "#fff", borderRadius: 20, padding: 16, gap: 8, borderWidth: 1.5, borderColor: C.azul100 },
  titulo: { fontFamily: F.extra, fontSize: 15, color: C.texto },
  texto: { fontFamily: F.regular, fontSize: 13, color: C.suave, lineHeight: 18 },
  fila: { flexDirection: "row", gap: 10, marginTop: 4 },
  boton: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 14, paddingVertical: 13 },
  botonTexto: { color: "#fff", fontFamily: F.negrita, fontSize: 14 },
});
