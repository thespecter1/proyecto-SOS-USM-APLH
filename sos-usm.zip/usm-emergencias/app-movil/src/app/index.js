// Pantalla 1: bienvenida y permiso de ubicación
import { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono, { Logo } from "../componentes/Icono";
import { BotonEnlace, BotonPrimario } from "../componentes/UI";
import { useSOS } from "../estado/SOSContext";
import { C, F, SOMBRA } from "../tema";

const BENEFICIOS = [
  { icono: "pin", titulo: "Ubicación en tiempo real", texto: "Los Bomberos Universitarios llegan directo a donde estás." },
  { icono: "ia", titulo: "Asistencia con IA", texto: "Recibe al instante instrucciones de qué hacer." },
  { icono: "chat", titulo: "Chat directo", texto: "Comunícate con la central mientras llega la ayuda." },
];

export default function Bienvenida() {
  const insets = useSafeAreaInsets();
  const { listo, perfil, permisoConcedido, iniciarGPS, iniciarSimulacion } = useSOS();
  // Después del permiso: si la persona aún no se registró, se le muestra el registro
  const siguiente = perfil.registrado ? "/inicio" : "/elegir-registro";
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState(null);

  // Si el permiso ya fue concedido antes, entrar directo
  useEffect(() => {
    if (!listo) return;
    (async () => {
      if (await permisoConcedido()) {
        iniciarGPS().catch(() => {});
        router.replace(siguiente);
      }
    })();
  }, [listo, siguiente, permisoConcedido, iniciarGPS]);

  const permitir = async () => {
    setCargando(true);
    setError(null);
    try {
      await iniciarGPS();
      router.replace(siguiente);
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.fondo }} contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}>
      <LinearGradient colors={[C.azul500, C.azul800]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={[e.hero, { paddingTop: insets.top + 48 }]}>
        <View style={e.logo}><Logo tamano={88} /></View>
        <Text style={e.titulo}>SOS USM</Text>
        <Text style={e.subtitulo}>Emergencias con inteligencia artificial y geolocalización{"\n"}Universidad Santa María</Text>
      </LinearGradient>

      <View style={e.cuerpo}>
        <View style={e.tarjeta}>
          {BENEFICIOS.map((b, i) => (
            <View key={b.icono} style={[e.beneficio, i > 0 && e.separador]}>
              <View style={e.icono}><Icono nombre={b.icono} tamano={22} color={C.azul600} /></View>
              <View style={{ flex: 1 }}>
                <Text style={e.bTitulo}>{b.titulo}</Text>
                <Text style={e.bTexto}>{b.texto}</Text>
              </View>
            </View>
          ))}
        </View>
        <Text style={e.privacidad}>
          Para estudiantes, profesores, personal administrativo, seguridad y limpieza. Tu ubicación solo se comparte mientras usas la app.
        </Text>
        <BotonPrimario texto={error ? "Reintentar" : "Permitir ubicación y continuar"} onPress={permitir} cargando={cargando} />
        {error ? (
          <>
            <Text style={e.error}>{error}</Text>
            <BotonEnlace texto="Modo demostración: simular ubicación en el campus" onPress={() => { iniciarSimulacion(); router.replace(siguiente); }} />
          </>
        ) : null}
      </View>
    </ScrollView>
  );
}

const e = StyleSheet.create({
  hero: { alignItems: "center", paddingHorizontal: 24, paddingBottom: 64, borderBottomLeftRadius: 36, borderBottomRightRadius: 36 },
  logo: { borderRadius: 24, overflow: "hidden", borderWidth: 4, borderColor: "rgba(255,255,255,0.25)", boxShadow: "0px 12px 30px rgba(0,0,0,0.25)" },
  titulo: { color: "#fff", fontFamily: F.extra, fontSize: 34, marginTop: 18, letterSpacing: -0.5 },
  subtitulo: { color: "rgba(255,255,255,0.85)", fontFamily: F.regular, fontSize: 14, textAlign: "center", lineHeight: 20, marginTop: 6 },
  cuerpo: { paddingHorizontal: 20, marginTop: -36, gap: 16 },
  tarjeta: { backgroundColor: "#fff", borderRadius: 20, paddingHorizontal: 16, paddingVertical: 4, ...SOMBRA },
  beneficio: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 12 },
  separador: { borderTopWidth: 1, borderTopColor: C.borde },
  icono: { width: 44, height: 44, borderRadius: 14, backgroundColor: C.azul50, alignItems: "center", justifyContent: "center" },
  bTitulo: { fontFamily: F.negrita, fontSize: 15, color: C.texto },
  bTexto: { fontFamily: F.regular, fontSize: 13, color: C.suave, marginTop: 2, lineHeight: 18 },
  privacidad: { fontFamily: F.regular, fontSize: 13, color: C.suave, textAlign: "center", lineHeight: 19 },
  error: { fontFamily: F.medio, fontSize: 14, color: C.peligro, textAlign: "center" },
});
