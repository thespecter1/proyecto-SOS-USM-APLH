// Pantalla 2: inicio con las dos opciones (normal = 2/4 de pantalla, alta prioridad = 1/4)
import { Pressable, StyleSheet, Text, View, useWindowDimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono from "../componentes/Icono";
import { Cabecera, ChipGPS } from "../componentes/UI";
import { useSOS } from "../estado/SOSContext";
import { C, F } from "../tema";

export default function Inicio() {
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const compacto = height < 720;
  const { ubicacion, simulada, incidente, perfil, sinSenal, pendientes } = useSOS();
  const activa = incidente && incidente.estado !== "resuelto";

  const textoUbic = ubicacion
    ? `Ubicación activa · ±${Math.round(ubicacion.precision ?? 0)} m${simulada ? " (simulada)" : ""}`
    : "Obteniendo ubicación…";

  return (
    <View style={{ flex: 1, backgroundColor: C.fondo }}>
      <Cabecera derecha={<ChipGPS />} />
      <View style={[e.cuerpo, { paddingBottom: insets.bottom + 16 }]}>
        <View>
          <Text style={e.titulo}>¿Qué está pasando?</Text>
          <View style={e.filaEstado}>
            <View style={e.ubic}>
              <View style={[e.punto, !ubicacion && { backgroundColor: C.aviso }]} />
              <Text style={e.ubicTexto} numberOfLines={1}>{textoUbic}</Text>
            </View>
            {perfil.registrado ? (
              <Pressable onPress={() => router.push("/registro?editar=1")} style={e.perfil} accessibilityRole="button" accessibilityLabel="Ver o editar mi registro">
                <Icono nombre="usuario" tamano={15} color={C.azul700} />
                <Text style={e.perfilTexto}>Mi registro</Text>
              </Pressable>
            ) : null}
          </View>
        </View>

        {sinSenal ? (
          <View style={e.offline}>
            <View style={e.offlinePunto} />
            <Text style={e.offlineTexto}>
              <Text style={{ fontFamily: F.negrita }}>Sin conexión con la central.</Text> Puedes reportar igual: la IA del teléfono te orientará y la alerta se enviará al volver la señal.
              {pendientes ? ` (${pendientes} pendiente${pendientes > 1 ? "s" : ""})` : ""}
            </Text>
          </View>
        ) : null}

        {!perfil.registrado ? (
          <Pressable onPress={() => router.push("/registro?editar=1")} style={e.sinRegistro} accessibilityRole="button">
            <Icono nombre="usuario" tamano={20} color={C.aviso} />
            <Text style={e.sinRegistroTexto}>
              <Text style={{ fontFamily: F.negrita }}>Completa tu registro</Text> para que, en una alerta SOS, los bomberos reciban tus datos.
            </Text>
            <Icono nombre="flecha" tamano={18} color={C.aviso} />
          </Pressable>
        ) : null}

        {activa ? (
          <Pressable onPress={() => router.push("/emergencia")} style={e.activa} accessibilityRole="button">
            <View style={e.pulso} />
            <View style={{ flex: 1 }}>
              <Text style={e.activaTitulo}>Tienes una emergencia activa</Text>
              <Text style={e.activaTexto}>Toca para ver el estado y el chat</Text>
            </View>
            <Icono nombre="flecha" color="#fff" />
          </Pressable>
        ) : null}

        {/* Emergencia normal: ocupa dos cuartos de la pantalla */}
        <Pressable
          onPress={() => router.push("/reporte")}
          style={({ pressed }) => [e.grandeMarco, { transform: [{ scale: pressed ? 0.99 : 1 }] }]}
          accessibilityRole="button"
          accessibilityLabel="Reportar una emergencia"
        >
          <LinearGradient colors={[C.azul500, C.azul700, C.azul800]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={e.grande}>
            <View style={[e.grandeIcono, compacto && { width: 56, height: 56, borderRadius: 18 }]}>
              <Icono nombre="documento" tamano={compacto ? 28 : 38} color="#fff" />
            </View>
            <Text style={[e.grandeTitulo, compacto && { fontSize: 21 }]}>Reportar una emergencia</Text>
            <Text style={[e.grandeTexto, compacto && { fontSize: 13 }]}>
              Accidentes, malestares, incendios, fugas o riesgos de seguridad. Describe lo que ocurre y recibe instrucciones de inmediato.
            </Text>
            {!compacto ? (
              <View style={e.cta}>
                <Text style={e.ctaTexto}>Comenzar reporte</Text>
                <Icono nombre="flecha" tamano={16} color={C.azul700} />
              </View>
            ) : null}
          </LinearGradient>
        </Pressable>

        {/* Alta prioridad: cuarto inferior, completamente rojo */}
        <Pressable
          onPress={() => router.push("/alta-prioridad")}
          style={({ pressed }) => [e.rojoMarco, { transform: [{ scale: pressed ? 0.99 : 1 }] }]}
          accessibilityRole="button"
          accessibilityLabel="Emergencia de alta prioridad"
        >
          <LinearGradient colors={[C.peligroClaro, C.peligro, C.peligroOscuro]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={e.rojo}>
            <View style={e.rojoFila}>
              <Icono nombre="alerta" tamano={26} color="#fff" />
              <Text style={[e.rojoTitulo, compacto && { fontSize: 17 }]}>Emergencia de alta prioridad</Text>
              <Icono nombre="flecha" color="#fff" />
            </View>
            <Text style={[e.rojoTexto, compacto && { fontSize: 12 }]}>
              Solo para casos extremadamente críticos con riesgo inminente para la vida. El uso indebido puede traer repercusiones.
            </Text>
          </LinearGradient>
        </Pressable>
      </View>
    </View>
  );
}

const e = StyleSheet.create({
  cuerpo: { flex: 1, paddingHorizontal: 16, paddingTop: 16, gap: 12 },
  titulo: { fontFamily: F.extra, fontSize: 24, color: C.texto, letterSpacing: -0.5 },
  filaEstado: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, marginTop: 4 },
  ubic: { flex: 1, flexDirection: "row", alignItems: "center", gap: 7 },
  perfil: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: C.azul50, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 6 },
  perfilTexto: { fontFamily: F.negrita, fontSize: 12, color: C.azul700 },
  sinRegistro: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: C.aviso50, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11, borderWidth: 1, borderColor: "#f3d9a4" },
  sinRegistroTexto: { flex: 1, fontFamily: F.regular, fontSize: 13, color: "#6b4000", lineHeight: 18 },
  punto: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.ok },
  ubicTexto: { flexShrink: 1, fontFamily: F.regular, fontSize: 14, color: C.suave },
  offline: { flexDirection: "row", alignItems: "flex-start", gap: 10, backgroundColor: "#fff1e0", borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11, borderWidth: 1, borderColor: "#f3d1a4" },
  offlinePunto: { width: 9, height: 9, borderRadius: 5, backgroundColor: C.aviso, marginTop: 5 },
  offlineTexto: { flex: 1, fontFamily: F.regular, fontSize: 12.5, color: "#6b4000", lineHeight: 18 },
  activa: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: C.azul700, borderRadius: 18, paddingVertical: 12, paddingHorizontal: 14 },
  pulso: { width: 11, height: 11, borderRadius: 6, backgroundColor: "#ffd166" },
  activaTitulo: { color: "#fff", fontFamily: F.negrita, fontSize: 14 },
  activaTexto: { color: "rgba(255,255,255,0.8)", fontFamily: F.regular, fontSize: 12 },
  grandeMarco: { flex: 2, borderRadius: 28, overflow: "hidden", boxShadow: "0px 14px 34px rgba(21, 84, 209, 0.35)" },
  grande: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10, paddingHorizontal: 22, paddingVertical: 18 },
  grandeIcono: { width: 76, height: 76, borderRadius: 24, backgroundColor: "rgba(255,255,255,0.16)", borderWidth: 1.5, borderColor: "rgba(255,255,255,0.3)", alignItems: "center", justifyContent: "center" },
  grandeTitulo: { color: "#fff", fontFamily: F.extra, fontSize: 24, textAlign: "center", letterSpacing: -0.4 },
  grandeTexto: { color: "rgba(255,255,255,0.88)", fontFamily: F.regular, fontSize: 14, lineHeight: 20, textAlign: "center", maxWidth: 300 },
  cta: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#fff", borderRadius: 999, paddingHorizontal: 16, paddingVertical: 10, marginTop: 4 },
  ctaTexto: { color: C.azul700, fontFamily: F.negrita, fontSize: 14 },
  rojoMarco: { flex: 1, borderRadius: 24, overflow: "hidden", boxShadow: "0px 12px 28px rgba(217, 45, 58, 0.35)" },
  rojo: { flex: 1, justifyContent: "center", gap: 8, paddingHorizontal: 18, paddingVertical: 14 },
  rojoFila: { flexDirection: "row", alignItems: "center", gap: 10 },
  rojoTitulo: { flex: 1, color: "#fff", fontFamily: F.extra, fontSize: 19, letterSpacing: -0.2 },
  rojoTexto: { color: "rgba(255,255,255,0.92)", fontFamily: F.regular, fontSize: 13, lineHeight: 18 },
});
