// Registro del perfil: la persona lo llena en un momento de calma.
// Si después envía una alerta SOS, los bomberos reciben estos datos sin que tenga que escribir nada.
import { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import Icono from "../componentes/Icono";
import { BotonEnlace, BotonPrimario, Cabecera } from "../componentes/UI";
import { useSOS } from "../estado/SOSContext";
import { C, F, SOMBRA } from "../tema";

const TIPOS = [
  { valor: "estudiante", texto: "Estudiante" },
  { valor: "profesor", texto: "Profesor" },
  { valor: "administrativo", texto: "Personal administrativo" },
  { valor: "seguridad", texto: "Seguridad" },
  { valor: "limpieza", texto: "Limpieza y mantenimiento" },
];
const SANGRE = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "No sé"];
const AREA = {
  estudiante: ["Carrera", "Ej. Ingeniería de Sistemas"],
  profesor: ["Facultad o escuela", "Ej. Facultad de Ingeniería"],
  administrativo: ["Departamento", "Ej. Control de Estudios"],
  seguridad: ["Área o puesto", "Ej. Entrada principal"],
  limpieza: ["Área de trabajo", "Ej. Edificio A"],
};

function Seccion({ icono, titulo, nota, children }) {
  return (
    <View style={e.seccion}>
      <View style={e.seccionCab}>
        <View style={e.seccionIcono}><Icono nombre={icono} tamano={18} color={C.azul600} /></View>
        <View style={{ flex: 1 }}>
          <Text style={e.seccionTitulo}>{titulo}</Text>
          {nota ? <Text style={e.seccionNota}>{nota}</Text> : null}
        </View>
      </View>
      {children}
    </View>
  );
}

function Campo({ etiqueta, obligatorio, style, ...props }) {
  return (
    <View style={[{ gap: 6 }, style]}>
      <Text style={e.etiqueta}>{etiqueta}{obligatorio ? <Text style={{ color: C.peligro }}> *</Text> : null}</Text>
      <TextInput style={[e.input, props.multiline && e.area]} placeholderTextColor="#9aa6bf" textAlignVertical={props.multiline ? "top" : "center"} {...props} />
    </View>
  );
}

export default function Registro() {
  const insets = useSafeAreaInsets();
  const { editar } = useLocalSearchParams();
  const editando = editar === "1";
  const { perfil, guardarPerfil } = useSOS();
  const [d, setD] = useState({ ...perfil, edad: perfil.edad ? String(perfil.edad) : "" });
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);
  const [aviso, setAviso] = useState(null);
  const cambiar = (campo) => (valor) => setD((x) => ({ ...x, [campo]: valor }));
  const [areaTitulo, areaEjemplo] = AREA[d.tipoUsuario] || AREA.estudiante;

  const guardar = async () => {
    if (!d.nombre.trim() || !d.cedula.trim() || !d.telefono.trim()) {
      setError("Completa los campos obligatorios: nombre, cédula y teléfono.");
      return;
    }
    if (!d.consentimiento) {
      setError("Debes autorizar el uso de tus datos para que los bomberos puedan recibirlos.");
      return;
    }
    setError(null);
    setGuardando(true);
    const limpio = Object.fromEntries(Object.entries(d).map(([k, v]) => [k, typeof v === "string" ? v.trim() : v]));
    const { sincronizado } = await guardarPerfil(limpio);
    setGuardando(false);
    if (!sincronizado) {
      setAviso("Tu registro quedó guardado en el teléfono. Se enviará al servidor en cuanto haya conexión.");
      setTimeout(() => salir(), 2200);
    } else salir();
  };
  const salir = () => (editando && router.canGoBack() ? router.back() : router.replace("/inicio"));

  return (
    <View style={{ flex: 1, backgroundColor: C.fondo }}>
      <Cabecera atras={editando} titulo={editando ? "Mi registro" : "Registro"} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={[e.cuerpo, { paddingBottom: insets.bottom + 28 }]} keyboardShouldPersistTaps="handled">
          <View style={e.intro}>
            <Icono nombre="escudo" tamano={28} color="#fff" />
            <View style={{ flex: 1 }}>
              <Text style={e.introTitulo}>{editando ? "Mantén tus datos al día" : "Regístrate en un momento de calma"}</Text>
              <Text style={e.introTexto}>
                Si algún día envías una alerta SOS, los Bomberos Universitarios recibirán estos datos automáticamente, sin que tengas que escribir nada.
              </Text>
            </View>
          </View>

          <Seccion icono="usuario" titulo="Datos personales">
            <View style={{ gap: 8 }}>
              <Text style={e.etiqueta}>Soy parte de la comunidad USM como</Text>
              <View style={e.chips}>
                {TIPOS.map((t) => {
                  const activo = d.tipoUsuario === t.valor;
                  return (
                    <Pressable key={t.valor} onPress={() => cambiar("tipoUsuario")(t.valor)} style={[e.chip, activo && e.chipActivo]} accessibilityRole="radio" accessibilityState={{ selected: activo }}>
                      <Text style={[e.chipTexto, activo && { color: "#fff" }]}>{t.texto}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
            <Campo etiqueta="Nombre completo" obligatorio value={d.nombre} onChangeText={cambiar("nombre")} placeholder="Ej. María Pérez" autoComplete="name" maxLength={80} />
            <View style={e.dos}>
              <Campo style={{ flex: 1 }} etiqueta="Cédula" obligatorio value={d.cedula} onChangeText={(v) => cambiar("cedula")(v.replace(/[^\dVvEe-]/g, "").toUpperCase())} placeholder="V-28123456" maxLength={14} autoCapitalize="characters" />
              <Campo style={{ width: 88 }} etiqueta="Edad" value={d.edad} onChangeText={(v) => cambiar("edad")(v.replace(/\D/g, ""))} placeholder="21" keyboardType="number-pad" maxLength={3} />
            </View>
            <Campo etiqueta="Teléfono" obligatorio value={d.telefono} onChangeText={cambiar("telefono")} placeholder="Ej. 0414-1234567" keyboardType="phone-pad" autoComplete="tel" maxLength={20} />
            <Campo etiqueta={areaTitulo} value={d.carrera} onChangeText={cambiar("carrera")} placeholder={areaEjemplo} maxLength={80} />
          </Seccion>

          <Seccion icono="corazon" titulo="Información médica" nota="Opcional, pero puede salvarte la vida.">
            <View style={{ gap: 8 }}>
              <Text style={e.etiqueta}>Tipo de sangre</Text>
              <View style={e.chips}>
                {SANGRE.map((t) => {
                  const activo = d.sangre === t;
                  return (
                    <Pressable key={t} onPress={() => cambiar("sangre")(activo ? "" : t)} style={[e.chipSangre, activo && e.chipActivo]} accessibilityRole="radio" accessibilityState={{ selected: activo }}>
                      <Text style={[e.chipTexto, activo && { color: "#fff" }]}>{t}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
            <Campo etiqueta="Condiciones médicas" value={d.condiciones} onChangeText={cambiar("condiciones")} placeholder="Ej. asma, diabetes, epilepsia, problemas cardíacos" multiline maxLength={300} />
            <Campo etiqueta="Alergias" value={d.alergias} onChangeText={cambiar("alergias")} placeholder="Ej. penicilina, picaduras de abeja, maní" multiline maxLength={300} />
            <Campo etiqueta="Medicamentos que tomas" value={d.medicamentos} onChangeText={cambiar("medicamentos")} placeholder="Ej. salbutamol (inhalador)" multiline maxLength={300} />
          </Seccion>

          <Seccion icono="telefono" titulo="Contacto de emergencia" nota="A quién avisar si te ocurre algo.">
            <Campo etiqueta="Nombre" value={d.contactoNombre} onChangeText={cambiar("contactoNombre")} placeholder="Ej. Carmen Pérez" maxLength={80} />
            <View style={e.dos}>
              <Campo style={{ flex: 1 }} etiqueta="Parentesco" value={d.contactoParentesco} onChangeText={cambiar("contactoParentesco")} placeholder="Ej. Madre" maxLength={40} />
              <Campo style={{ flex: 1.3 }} etiqueta="Teléfono" value={d.contactoTelefono} onChangeText={cambiar("contactoTelefono")} placeholder="0412-7654321" keyboardType="phone-pad" maxLength={20} />
            </View>
          </Seccion>

          <Pressable onPress={() => cambiar("consentimiento")(!d.consentimiento)} style={e.acepto} accessibilityRole="checkbox" accessibilityState={{ checked: d.consentimiento }}>
            <View style={[e.caja, d.consentimiento && e.cajaMarcada]}>{d.consentimiento ? <Icono nombre="check" tamano={15} color="#fff" /> : null}</View>
            <Text style={e.aceptoTexto}>
              Autorizo que mis datos se guarden y se compartan con los Bomberos Universitarios <Text style={{ fontFamily: F.negrita }}>únicamente en una emergencia</Text>: cuando yo envíe una alerta o cuando otra persona reporte que me ocurrió algo.
            </Text>
          </Pressable>

          {error ? <Text style={e.error}>{error}</Text> : null}
          {aviso ? <Text style={e.aviso}>{aviso}</Text> : null}
          <BotonPrimario texto={editando ? "Guardar cambios" : "Guardar registro"} icono="check" onPress={guardar} cargando={guardando} />
          {!editando ? <BotonEnlace texto="Completar más tarde" onPress={() => router.replace("/inicio")} /> : null}
          <Text style={e.nota}>Los campos con <Text style={{ color: C.peligro }}>*</Text> son obligatorios. Puedes editar tu registro cuando quieras desde la pantalla de inicio.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const e = StyleSheet.create({
  cuerpo: { padding: 16, gap: 16 },
  intro: { flexDirection: "row", gap: 12, alignItems: "flex-start", backgroundColor: C.azul700, borderRadius: 20, padding: 16 },
  introTitulo: { color: "#fff", fontFamily: F.extra, fontSize: 17 },
  introTexto: { color: "rgba(255,255,255,0.88)", fontFamily: F.regular, fontSize: 13, lineHeight: 19, marginTop: 4 },
  seccion: { backgroundColor: "#fff", borderRadius: 20, padding: 16, gap: 14, ...SOMBRA },
  seccionCab: { flexDirection: "row", alignItems: "center", gap: 10 },
  seccionIcono: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.azul50, alignItems: "center", justifyContent: "center" },
  seccionTitulo: { fontFamily: F.extra, fontSize: 16, color: C.texto },
  seccionNota: { fontFamily: F.regular, fontSize: 12, color: C.suave, marginTop: 1 },
  etiqueta: { fontFamily: F.negrita, fontSize: 13, color: C.texto },
  input: { fontFamily: F.medio, fontSize: 16, color: C.texto, backgroundColor: C.fondo, borderWidth: 1.5, borderColor: C.borde, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12 },
  area: { minHeight: 64 },
  dos: { flexDirection: "row", gap: 10 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: "#fff", borderWidth: 1.5, borderColor: C.borde },
  chipSangre: { minWidth: 52, alignItems: "center", paddingHorizontal: 12, paddingVertical: 9, borderRadius: 12, backgroundColor: "#fff", borderWidth: 1.5, borderColor: C.borde },
  chipActivo: { backgroundColor: C.azul600, borderColor: C.azul600 },
  chipTexto: { fontFamily: F.semi, fontSize: 14, color: C.texto },
  acepto: { flexDirection: "row", gap: 12, alignItems: "flex-start", paddingHorizontal: 4 },
  caja: { width: 24, height: 24, borderRadius: 8, borderWidth: 2, borderColor: C.azul100, backgroundColor: "#fff", alignItems: "center", justifyContent: "center" },
  cajaMarcada: { backgroundColor: C.azul600, borderColor: C.azul600 },
  aceptoTexto: { flex: 1, fontFamily: F.regular, fontSize: 13, color: C.texto, lineHeight: 19 },
  error: { fontFamily: F.medio, fontSize: 14, color: C.peligro, textAlign: "center" },
  aviso: { fontFamily: F.medio, fontSize: 13, color: C.aviso, backgroundColor: C.aviso50, borderRadius: 12, padding: 12, textAlign: "center" },
  nota: { fontFamily: F.regular, fontSize: 12, color: C.suave, textAlign: "center", lineHeight: 18 },
});
