// Pantalla 3: emergencia de alta prioridad (advertencia + confirmación + SOS)
import { useState } from "react";
import { ActivityIndicator, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono from "../componentes/Icono";
import BotonSOS from "../componentes/BotonSOS";
import { BotonEnlace, Cabecera } from "../componentes/UI";
import { useSOS } from "../estado/SOSContext";
import { C, F, SOMBRA } from "../tema";

const USAR = ["Una persona inconsciente o que no respira", "Un incendio fuera de control", "Una agresión con armas", "Personas atrapadas o un derrumbe"];
const NO_USAR = ["Malestares o golpes leves", "Consultas o pruebas", "Situaciones que puedes describir con calma"];

export default function AltaPrioridad() {
  const insets = useSafeAreaInsets();
  const { enviarSOS, perfil } = useSOS();
  const [acepto, setAcepto] = useState(false);
  const [presionando, setPresionando] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState(null);

  const enviar = async () => {
    setEnviando(true);
    setError(null);
    try {
      await enviarSOS();
      setTimeout(() => { setEnviando(false); router.replace("/emergencia"); }, 1800);
    } catch (err) {
      setEnviando(false);
      setError(err.message || "No se pudo enviar la alerta. Revisa tu conexión e intenta de nuevo.");
    }
  };

  const ayuda = !acepto ? "Marca la casilla de confirmación para activar"
    : presionando ? "Sigue presionando…" : "Mantén presionado 3 segundos para enviar la alerta";

  return (
    <View style={{ flex: 1, backgroundColor: C.fondo }}>
      <Cabecera atras titulo="Alta prioridad" />
      <ScrollView contentContainerStyle={[e.cuerpo, { paddingBottom: insets.bottom + 24 }]} scrollEnabled={!presionando}>
        <View style={e.adv}>
          <View style={e.advCab}>
            <Icono nombre="alerta" tamano={26} color={C.peligro} />
            <Text style={e.advTitulo}>Solo para casos extremadamente críticos</Text>
          </View>
          <Text style={e.parrafo}>
            Esta alerta se envía con <Text style={e.negrita}>máxima prioridad</Text> y moviliza de inmediato a los Bomberos Universitarios, <Text style={e.negrita}>sin que tengas que escribir nada</Text>.
          </Text>
          <View style={e.listas}>
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={e.listaTitulo}>ÚSALA SI HAY</Text>
              {USAR.map((t) => (<View key={t} style={e.item}><View style={e.vinetaSi} /><Text style={e.itemTexto}>{t}</Text></View>))}
            </View>
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={e.listaTitulo}>NO LA USES PARA</Text>
              {NO_USAR.map((t) => (<View key={t} style={e.item}><View style={e.vinetaNo} /><Text style={e.itemTexto}>{t}</Text></View>))}
            </View>
          </View>
          <View style={e.legal}>
            <Text style={e.legalTexto}>
              Cada alerta queda registrada con tu dispositivo, ubicación y hora. <Text style={e.legalNegrita}>El uso indebido de esta opción puede traer repercusiones disciplinarias</Text> según el reglamento de la Universidad Santa María.
            </Text>
          </View>
          <Pressable onPress={() => setAcepto(!acepto)} style={e.acepto} accessibilityRole="checkbox" accessibilityState={{ checked: acepto }}>
            <View style={[e.caja, acepto && e.cajaMarcada]}>{acepto ? <Icono nombre="check" tamano={15} color="#fff" /> : null}</View>
            <Text style={e.aceptoTexto}>Entiendo y confirmo que se trata de una emergencia crítica.</Text>
          </Pressable>
        </View>

        {/* Qué datos recibirán los bomberos */}
        {perfil.registrado ? (
          <View style={e.ficha}>
            <View style={e.fichaCab}>
              <Icono nombre="escudo" tamano={22} color={C.azul600} />
              <Text style={e.fichaTitulo}>Los bomberos recibirán tu registro</Text>
            </View>
            <Text style={e.fichaTexto}>
              {[perfil.nombre, perfil.cedula, perfil.sangre && perfil.sangre !== "No sé" ? `Sangre ${perfil.sangre}` : null, perfil.condiciones || null]
                .filter(Boolean).join(" · ")}
            </Text>
            {perfil.contactoNombre ? <Text style={e.fichaSub}>Contacto de emergencia: {perfil.contactoNombre}{perfil.contactoTelefono ? ` (${perfil.contactoTelefono})` : ""}</Text> : null}
          </View>
        ) : (
          <Pressable onPress={() => router.push("/registro?editar=1")} style={e.sinFicha} accessibilityRole="button">
            <Icono nombre="usuario" tamano={20} color={C.aviso} />
            <Text style={e.sinFichaTexto}>
              No estás registrado: la alerta llegará <Text style={{ fontFamily: F.negrita }}>sin tus datos</Text>. Toca aquí para registrarte.
            </Text>
          </Pressable>
        )}

        <View style={e.zonaSOS}>
          <BotonSOS deshabilitado={!acepto || enviando} onCompletado={enviar} onEstado={setPresionando} />
          <Text style={e.ayuda}>{ayuda}</Text>
          {error ? <Text style={e.error}>{error}</Text> : null}
        </View>
        <BotonEnlace texto="No es tan grave: reportar una emergencia normal" onPress={() => router.replace("/reporte")} />
      </ScrollView>

      <Modal visible={enviando} transparent animationType="fade" statusBarTranslucent>
        <View style={e.overlay}>
          <View style={e.onda}><Text style={e.ondaTexto}>SOS</Text></View>
          <Text style={e.overlayTitulo}>Alerta SOS enviada</Text>
          <Text style={e.overlayTexto}>Los Bomberos Universitarios recibieron tu ubicación con máxima prioridad.</Text>
          <ActivityIndicator color="#fff" style={{ marginTop: 12 }} />
        </View>
      </Modal>
    </View>
  );
}

const e = StyleSheet.create({
  cuerpo: { padding: 16, gap: 18 },
  adv: { backgroundColor: "#fff", borderRadius: 20, borderWidth: 1.5, borderColor: C.peligroBorde, padding: 18, gap: 12, ...SOMBRA },
  advCab: { flexDirection: "row", alignItems: "center", gap: 10 },
  advTitulo: { flex: 1, fontFamily: F.extra, fontSize: 17, color: C.peligro, lineHeight: 22 },
  parrafo: { fontFamily: F.regular, fontSize: 14, color: C.texto, lineHeight: 21 },
  negrita: { fontFamily: F.negrita },
  listas: { flexDirection: "row", gap: 12 },
  listaTitulo: { fontFamily: F.negrita, fontSize: 11, color: C.suave, letterSpacing: 0.8 },
  item: { flexDirection: "row", gap: 8, alignItems: "flex-start" },
  vinetaSi: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.peligro, marginTop: 5 },
  vinetaNo: { width: 9, height: 2, backgroundColor: C.suave, marginTop: 8 },
  itemTexto: { flex: 1, fontFamily: F.regular, fontSize: 13, color: C.texto, lineHeight: 18 },
  legal: { backgroundColor: C.aviso50, borderRadius: 12, padding: 12 },
  legalTexto: { fontFamily: F.regular, fontSize: 13, color: "#6b4000", lineHeight: 19 },
  legalNegrita: { fontFamily: F.negrita },
  acepto: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  caja: { width: 24, height: 24, borderRadius: 8, borderWidth: 2, borderColor: C.azul100, backgroundColor: "#fff", alignItems: "center", justifyContent: "center" },
  cajaMarcada: { backgroundColor: C.azul600, borderColor: C.azul600 },
  aceptoTexto: { flex: 1, fontFamily: F.semi, fontSize: 14, color: C.texto, lineHeight: 20 },
  zonaSOS: { alignItems: "center", gap: 10 },
  ficha: { backgroundColor: "#fff", borderRadius: 18, padding: 14, gap: 6, borderWidth: 1.5, borderColor: C.azul100 },
  fichaCab: { flexDirection: "row", alignItems: "center", gap: 8 },
  fichaTitulo: { fontFamily: F.extra, fontSize: 15, color: C.texto },
  fichaTexto: { fontFamily: F.medio, fontSize: 13, color: C.texto, lineHeight: 19 },
  fichaSub: { fontFamily: F.regular, fontSize: 12, color: C.suave },
  sinFicha: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: C.aviso50, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: "#f3d9a4" },
  sinFichaTexto: { flex: 1, fontFamily: F.regular, fontSize: 13, color: "#6b4000", lineHeight: 18 },
  ayuda: { fontFamily: F.regular, fontSize: 13, color: C.suave, textAlign: "center" },
  error: { fontFamily: F.medio, fontSize: 13, color: C.peligro, textAlign: "center" },
  overlay: { flex: 1, backgroundColor: "rgba(10, 31, 77, 0.96)", alignItems: "center", justifyContent: "center", padding: 24, gap: 8 },
  onda: { width: 96, height: 96, borderRadius: 48, backgroundColor: C.peligro, alignItems: "center", justifyContent: "center", boxShadow: "0px 0px 0px 14px rgba(217, 45, 58, 0.25)" },
  ondaTexto: { color: "#fff", fontFamily: F.extra, fontSize: 26 },
  overlayTitulo: { color: "#fff", fontFamily: F.extra, fontSize: 24, marginTop: 18 },
  overlayTexto: { color: "rgba(255,255,255,0.85)", fontFamily: F.regular, fontSize: 15, textAlign: "center", lineHeight: 21, maxWidth: 300 },
});
