// Pantalla 5: emergencia activa (estado, recomendaciones de la IA y chat con los bomberos)
import { useEffect, useRef, useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono from "../componentes/Icono";
import { BotonPrimario, Cabecera, ChipGPS } from "../componentes/UI";
import ContactoDirecto from "../componentes/ContactoDirecto";
import { useSOS } from "../estado/SOSContext";
import { C, F, SOMBRA } from "../tema";

const ORDEN = ["nuevo", "recibido", "en_camino", "en_sitio", "resuelto"];
const PASOS = ["Enviada", "Recibida", "En camino", "En sitio", "Atendida"];
const TITULOS = {
  pendiente: ["Sin conexión con la central", "Tu alerta está guardada y se enviará automáticamente en cuanto vuelva la señal."],
  nuevo: ["Alerta enviada", "Esperando confirmación de los Bomberos Universitarios…"],
  recibido: ["Alerta recibida", "Los Bomberos Universitarios están atendiendo tu caso."],
  en_camino: ["Ayuda en camino", "Una unidad se dirige a tu ubicación."],
  en_sitio: ["Unidad en el sitio", "Los bomberos llegaron a tu ubicación."],
  resuelto: ["Emergencia atendida", "El caso fue cerrado por los Bomberos Universitarios."],
};
const SEVERIDAD = {
  baja: ["Baja", C.ok50, C.ok], moderada: ["Moderada", C.aviso50, C.aviso],
  alta: ["Alta", "#ffe8d6", "#b54708"], critica: ["Crítica", C.peligro, "#fff"],
};
const hora = (ts) => new Date(ts).toLocaleTimeString("es-VE", { hour: "2-digit", minute: "2-digit" });

export default function Emergencia() {
  const insets = useSafeAreaInsets();
  const { incidente: inc, enviarMensaje, cerrarIncidente, sinSenal, reintentar } = useSOS();
  const [texto, setTexto] = useState("");
  const scroll = useRef(null);

  // Baja al chat solo cuando llega un mensaje nuevo (al abrir, se ve primero el estado)
  const totalMensajes = inc?.mensajes?.length ?? 0;
  const mensajesVistos = useRef(totalMensajes);
  useEffect(() => {
    if (totalMensajes <= mensajesVistos.current) return;
    mensajesVistos.current = totalMensajes;
    const t = setTimeout(() => scroll.current?.scrollToEnd({ animated: true }), 80);
    return () => clearTimeout(t);
  }, [totalMensajes]);

  if (!inc) {
    return (
      <View style={{ flex: 1, backgroundColor: C.fondo }}>
        <Cabecera atras titulo="Emergencia" />
        <View style={{ padding: 24, gap: 16 }}>
          <Text style={e.vacio}>No tienes ninguna emergencia activa.</Text>
          <BotonPrimario texto="Volver al inicio" onPress={() => router.replace("/inicio")} />
        </View>
      </View>
    );
  }

  const [titulo, detalle] = TITULOS[inc.estado] || TITULOS.nuevo;
  const idx = ORDEN.indexOf(inc.estado);
  const resuelto = inc.estado === "resuelto";
  const a = inc.analisis;
  const [sevTexto, sevFondo, sevColor] = SEVERIDAD[a?.severidad] || ["…", C.borde, C.texto];
  const pendiente = inc.estado === "pendiente";
  const colores = resuelto ? ["#0b6b40", C.ok] : pendiente ? ["#7a4700", "#b8730d"] : [C.azul800, C.azul600];

  const enviar = () => {
    enviarMensaje(texto);
    setTexto("");
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.fondo }}>
      <Cabecera atras titulo={inc.tipo === "panico" ? "Alerta SOS" : pendiente ? "Emergencia" : inc.id} derecha={<ChipGPS texto={pendiente ? "Guardada" : "En vivo"} />} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView ref={scroll} contentContainerStyle={e.cuerpo} keyboardShouldPersistTaps="handled">
          {/* Estado */}
          <LinearGradient colors={colores} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={e.estado}>
            <View style={e.estadoFila}>
              <View style={[e.pulso, { backgroundColor: resuelto ? "#fff" : idx <= 0 ? "#ffd166" : "#8fe3ff" }]} />
              <View style={{ flex: 1 }}>
                <Text style={e.estadoTitulo}>{titulo}</Text>
                <Text style={e.estadoDetalle}>{inc.asignado && idx > 0 ? `${detalle} Unidad: ${inc.asignado}` : detalle}</Text>
              </View>
            </View>
            <View style={e.linea}>
              {PASOS.map((p, i) => (
                <View key={p} style={e.paso}>
                  <View style={e.pasoPista}>
                    <View style={[e.pasoBarra, { opacity: i === 0 ? 0 : 1, backgroundColor: i <= idx ? "#fff" : "rgba(255,255,255,0.25)" }]} />
                    <View style={[e.pasoPunto, i <= idx && e.pasoPuntoHecho]} />
                  </View>
                  <Text style={[e.pasoTexto, i <= idx && e.pasoTextoHecho]}>{p}</Text>
                </View>
              ))}
            </View>
            {pendiente ? (
              <Pressable onPress={reintentar} style={e.reintentar} accessibilityRole="button">
                <Text style={e.reintentarTexto}>Reintentar ahora</Text>
              </Pressable>
            ) : null}
          </LinearGradient>

          {pendiente || (sinSenal && !resuelto) ? <ContactoDirecto tipo={inc.tipo === "panico" ? "sos" : "emergencia"} /> : null}

          {/* Recomendaciones de la IA */}
          <View style={e.tarjeta}>
            <View style={e.iaCab}>
              <View style={e.iaTag}><Icono nombre="ia" tamano={14} color={C.azul700} /><Text style={e.iaTagTexto}>Asistente IA</Text></View>
              <View style={[e.sev, { backgroundColor: sevFondo }]}><Text style={[e.sevTexto, { color: sevColor }]}>{sevTexto.toUpperCase()}</Text></View>
            </View>
            <Text style={e.iaTitulo}>{a ? a.subtipo : "Analizando la situación…"}</Text>
            <Text style={e.iaSub}>QUÉ HACER AHORA</Text>
            {a ? a.recomendaciones.map((r, i) => (
              <View key={i} style={e.rec}>
                <View style={e.recNum}><Text style={e.recNumTexto}>{i + 1}</Text></View>
                <Text style={e.recTexto}>{r}</Text>
              </View>
            )) : <Text style={e.cargando}>Generando recomendaciones…</Text>}
            {a ? (
              <Text style={e.fuente}>
                {a.fuente === "claude" ? `Refinado por IA en la nube · Claude (${a.modelo})`
                  : a.fuente === "protocolo" ? "Protocolo automático de alerta SOS · funciona sin internet"
                  : `IA en el teléfono · funciona sin internet${a.confianza ? ` · confianza ${a.confianza}%` : ""}`}
              </Text>
            ) : null}
          </View>

          {/* Chat */}
          <View style={[e.tarjeta, { padding: 0, overflow: "hidden" }]}>
            <View style={e.chatCab}>
              <View style={e.chatIcono}><Icono nombre="chat" color={C.azul600} /></View>
              <View><Text style={e.chatTitulo}>Bomberos Universitarios</Text><Text style={e.chatSub}>Chat directo con la central</Text></View>
            </View>
            <View style={e.mensajes}>
              {inc.mensajes.map((m) =>
                m.de === "sistema" ? (
                  <Text key={m.id} style={e.msgSistema}>{m.texto}</Text>
                ) : (
                  <View key={m.id} style={[e.msg, m.de === "usuario" ? e.msgUsuario : e.msgBomberos]}>
                    {m.de === "bomberos" ? <Text style={e.msgQuien}>Bomberos USM</Text> : null}
                    <Text style={[e.msgTexto, m.de === "usuario" && { color: "#fff" }]}>{m.texto}</Text>
                    <Text style={[e.msgHora, m.de === "usuario" && { color: "rgba(255,255,255,0.75)" }]}>{hora(m.ts)}</Text>
                  </View>
                )
              )}
            </View>
          </View>

          {resuelto ? (
            <Pressable onPress={() => { cerrarIncidente(); router.replace("/inicio"); }} style={e.cerrar}>
              <Text style={e.cerrarTexto}>Cerrar y volver al inicio</Text>
            </Pressable>
          ) : null}
        </ScrollView>

        {!resuelto ? (
          <View style={[e.barra, { paddingBottom: insets.bottom + 10 }]}>
            <TextInput
              style={e.entrada}
              value={texto}
              onChangeText={setTexto}
              placeholder={pendiente ? "Se enviará al recuperar la señal…" : "Escribe un mensaje…"}
              placeholderTextColor="#9aa6bf"
              onSubmitEditing={enviar}
              returnKeyType="send"
              maxLength={1000}
            />
            <Pressable onPress={enviar} style={e.enviar} accessibilityRole="button" accessibilityLabel="Enviar mensaje">
              <Icono nombre="enviar" color="#fff" />
            </Pressable>
          </View>
        ) : null}
      </KeyboardAvoidingView>
    </View>
  );
}

const e = StyleSheet.create({
  cuerpo: { padding: 16, gap: 14 },
  vacio: { fontFamily: F.medio, fontSize: 15, color: C.suave, textAlign: "center" },
  estado: { borderRadius: 20, padding: 16, paddingBottom: 12, gap: 16, ...SOMBRA },
  estadoFila: { flexDirection: "row", alignItems: "center", gap: 12 },
  pulso: { width: 12, height: 12, borderRadius: 6 },
  estadoTitulo: { color: "#fff", fontFamily: F.extra, fontSize: 18 },
  estadoDetalle: { color: "rgba(255,255,255,0.85)", fontFamily: F.regular, fontSize: 13, marginTop: 2 },
  linea: { flexDirection: "row" },
  paso: { flex: 1, alignItems: "center", gap: 6 },
  pasoPista: { width: "100%", height: 12, alignItems: "center", justifyContent: "center" },
  pasoBarra: { position: "absolute", left: "-50%", right: "50%", height: 2 },
  pasoPunto: { width: 10, height: 10, borderRadius: 5, backgroundColor: "rgba(255,255,255,0.3)" },
  pasoPuntoHecho: { backgroundColor: "#fff", borderWidth: 3, borderColor: "rgba(255,255,255,0.35)", width: 14, height: 14, borderRadius: 7 },
  pasoTexto: { fontFamily: F.medio, fontSize: 10, color: "rgba(255,255,255,0.6)", textAlign: "center" },
  pasoTextoHecho: { color: "#fff", fontFamily: F.negrita },
  tarjeta: { backgroundColor: "#fff", borderRadius: 20, padding: 16, ...SOMBRA },
  iaCab: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  iaTag: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: C.azul50, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  iaTagTexto: { fontFamily: F.negrita, fontSize: 12, color: C.azul700 },
  sev: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  sevTexto: { fontFamily: F.extra, fontSize: 11, letterSpacing: 0.5 },
  iaTitulo: { fontFamily: F.extra, fontSize: 20, color: C.texto, marginTop: 12 },
  iaSub: { fontFamily: F.negrita, fontSize: 11, color: C.suave, letterSpacing: 0.8, marginTop: 10, marginBottom: 8 },
  rec: { flexDirection: "row", gap: 10, marginBottom: 10 },
  recNum: { width: 28, height: 28, borderRadius: 9, backgroundColor: C.azul50, alignItems: "center", justifyContent: "center" },
  recNumTexto: { fontFamily: F.extra, fontSize: 13, color: C.azul700 },
  recTexto: { flex: 1, fontFamily: F.regular, fontSize: 15, color: C.texto, lineHeight: 21 },
  cargando: { fontFamily: F.regular, fontSize: 14, color: C.suave },
  fuente: { fontFamily: F.regular, fontSize: 11, color: C.suave, marginTop: 4 },
  chatCab: { flexDirection: "row", alignItems: "center", gap: 10, padding: 14, borderBottomWidth: 1, borderBottomColor: C.borde },
  chatIcono: { width: 36, height: 36, borderRadius: 12, backgroundColor: C.azul50, alignItems: "center", justifyContent: "center" },
  chatTitulo: { fontFamily: F.negrita, fontSize: 15, color: C.texto },
  chatSub: { fontFamily: F.regular, fontSize: 12, color: C.suave },
  mensajes: { padding: 14, gap: 8, backgroundColor: C.fondo, minHeight: 110 },
  msg: { maxWidth: "84%", paddingHorizontal: 13, paddingVertical: 9, borderRadius: 16 },
  msgUsuario: { alignSelf: "flex-end", backgroundColor: C.azul600, borderBottomRightRadius: 5 },
  msgBomberos: { alignSelf: "flex-start", backgroundColor: "#fff", borderWidth: 1, borderColor: C.borde, borderBottomLeftRadius: 5 },
  msgQuien: { fontFamily: F.negrita, fontSize: 12, color: C.azul700, marginBottom: 2 },
  msgTexto: { fontFamily: F.regular, fontSize: 15, color: C.texto, lineHeight: 20 },
  msgHora: { fontFamily: F.regular, fontSize: 10, color: C.suave, marginTop: 3 },
  msgSistema: { alignSelf: "center", fontFamily: F.regular, fontSize: 12, color: C.suave, textAlign: "center", paddingHorizontal: 8 },
  barra: { flexDirection: "row", gap: 8, paddingHorizontal: 12, paddingTop: 10, backgroundColor: "#fff", borderTopWidth: 1, borderTopColor: C.borde },
  entrada: { flex: 1, fontFamily: F.medio, fontSize: 15, color: C.texto, backgroundColor: C.fondo, borderWidth: 1.5, borderColor: C.borde, borderRadius: 999, paddingHorizontal: 16, paddingVertical: 11 },
  enviar: { width: 46, height: 46, borderRadius: 23, backgroundColor: C.azul600, alignItems: "center", justifyContent: "center" },
  reintentar: { alignSelf: "flex-start", backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 999, paddingHorizontal: 14, paddingVertical: 8 },
  reintentarTexto: { color: "#fff", fontFamily: F.negrita, fontSize: 13 },
  cerrar: { borderWidth: 1.5, borderColor: C.azul100, backgroundColor: "#fff", borderRadius: 14, paddingVertical: 14, alignItems: "center" },
  cerrarTexto: { fontFamily: F.negrita, fontSize: 15, color: C.azul700 },
});
