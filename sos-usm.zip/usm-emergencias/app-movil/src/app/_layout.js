import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import {
  useFonts,
  PlusJakartaSans_400Regular,
  PlusJakartaSans_500Medium,
  PlusJakartaSans_600SemiBold,
  PlusJakartaSans_700Bold,
  PlusJakartaSans_800ExtraBold,
} from "@expo-google-fonts/plus-jakarta-sans";
import { SOSProvider } from "../estado/SOSContext";
import { C } from "../tema";

export default function Raiz() {
  const [fuentesListas, errorFuentes] = useFonts({
    PlusJakartaSans_400Regular,
    PlusJakartaSans_500Medium,
    PlusJakartaSans_600SemiBold,
    PlusJakartaSans_700Bold,
    PlusJakartaSans_800ExtraBold,
  });
  if (!fuentesListas && !errorFuentes) return null;

  return (
    <SafeAreaProvider>
      <SOSProvider>
        <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.fondo }, animation: "slide_from_right" }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="inicio" options={{ gestureEnabled: false }} />
          <Stack.Screen name="elegir-registro" options={{ gestureEnabled: false }} />
          <Stack.Screen name="registro" />
          <Stack.Screen name="reporte" />
          <Stack.Screen name="alta-prioridad" />
          <Stack.Screen name="emergencia" />
        </Stack>
      </SOSProvider>
    </SafeAreaProvider>
  );
}
