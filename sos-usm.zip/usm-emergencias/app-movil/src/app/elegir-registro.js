// Después del permiso de GPS: ¿registrarse ahora o más tarde?
// Aparece cada vez que se abre la app mientras la persona no esté registrada.
import { Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono from "../componentes/Icono";
import { C, F } from "../tema";

export default function ElegirRegistro() {
  const insets = useSafeAreaInsets();
  return (
    <LinearGradient
      colors={[C.azul500, C.azul800]}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={[e.fondo, { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 32 }]}
    >
      <View style={e.centro}>
        <View style={e.icono}><Icono nombre="usuario" tamano={40} color="#fff" /></View>
        <Text style={e.titulo}>¿Quieres registrarte ahora o más tarde?</Text>
      </View>

      <View style={e.botones}>
        <Pressable
          onPress={() => router.replace("/registro")}
          style={({ pressed }) => [e.ahora, pressed && { opacity: 0.85 }]}
          accessibilityRole="button"
        >
          <Text style={e.ahoraTexto}>Registrarme ahora</Text>
        </Pressable>
        <Pressable
          onPress={() => router.replace("/inicio")}
          style={({ pressed }) => [e.luego, pressed && { opacity: 0.7 }]}
          accessibilityRole="button"
        >
          <Text style={e.luegoTexto}>Más tarde</Text>
        </Pressable>
      </View>
    </LinearGradient>
  );
}

const e = StyleSheet.create({
  fondo: { flex: 1, paddingHorizontal: 24 },
  centro: { flex: 1, alignItems: "center", justifyContent: "center", gap: 22 },
  icono: {
    width: 84, height: 84, borderRadius: 26, backgroundColor: "rgba(255,255,255,0.16)",
    borderWidth: 1.5, borderColor: "rgba(255,255,255,0.3)", alignItems: "center", justifyContent: "center",
  },
  titulo: { color: "#fff", fontFamily: F.extra, fontSize: 28, lineHeight: 34, textAlign: "center", letterSpacing: -0.4, maxWidth: 320 },
  botones: { gap: 12 },
  ahora: { backgroundColor: "#fff", borderRadius: 16, paddingVertical: 16, alignItems: "center" },
  ahoraTexto: { color: C.azul700, fontFamily: F.extra, fontSize: 17 },
  luego: { borderRadius: 16, paddingVertical: 16, alignItems: "center", borderWidth: 1.5, borderColor: "rgba(255,255,255,0.45)" },
  luegoTexto: { color: "#fff", fontFamily: F.negrita, fontSize: 17 },
});
