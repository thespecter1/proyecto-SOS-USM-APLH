// Pantalla 4: formulario de reporte de emergencia normal
import { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import Icono from "../componentes/Icono";
import { BotonPrimario, Cabecera } from "../componentes/UI";
import { useSOS } from "../estado/SOSContext";
import { C, F } from "../tema";

const TIPOS = [
  { valor: "estudiante", texto: "Estudiante" },
  { valor: "profesor", texto: "Profesor" },
  { valor: "administrativo", texto: "Personal administrativo" },
  { valor: "seguridad", texto: "Seguridad" },
  { valor: "limpieza", texto: "Limpieza y mantenimiento" },
];
const SUGERENCIAS = [
  ["Incendio", "Hay humo y fuego en "],
  ["Desmayo", "Una persona se desmayó y "],
  ["Caída", "Una persona se cayó y se golpeó "],
  ["Olor a gas", "Hay olor a gas en "],
  ["Dolor de pecho", "Alguien tiene dolor fuerte en el pecho "],
  ["Pelea", "Hay una pelea en "],
];

export default function Reporte() {
  const insets = useSafeAreaInsets();
  const { perfil, enviarReporte } = useSOS();
  const [tipoUsuario, setTipoUsuario] = useState(perfil.tipoUsuario || "estudiante");
  const [nombre, setNombre] = useState(perfil.nombre || "");
  const [edad, setEdad] = useState(perfil.edad ? String(perfil.edad) : "");
  const [rol, setRol] = useState("afectado");
  const [descripcion, setDescripcion] = useState("");
  // Observador: ¿conoce a la persona afectada? (null = sin responder)
  const [conoce, setConoce] = useState(null);
  const [afNombre, setAfNombre] = useState("");
  const [afEdad, setAfEdad] = useState("");
  const [afCedula, setAfCedula] = useState("");
  // Registrada: solo se pide quién necesita ayuda y qué pasó. No registrada: también sus datos básicos.
  const registrado = perfil.registrado;
  const tipoTexto = TIPOS.find((t) => t.valor === perfil.tipoUsuario)?.texto;
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState(null);

  // Datos de quien reporta: los del registro si existe, si no los del formulario
  const datosPersona = registrado
    ? { tipoUsuario: perfil.tipoUsuario, nombre: perfil.nombre, edad: perfil.edad ? String(perfil.edad) : "" }
    : { tipoUsuario, nombre: nombre.trim(), edad: edad.trim() };

  const enviar = async () => {
    if (!datosPersona.nombre) {
      setError("Escribe tu nombre.");
      return;
    }
    if (rol === "observador" && conoce === null) {
      setError("Indica si conoces a la persona afectada.");
      return;
    }
    if (rol === "observador" && conoce && !afNombre.trim()) {
      setError("Escribe el nombre de la persona afectada, o marca que no la conoces.");
      return;
    }
    if (!descripcion.trim()) {
      setError("Describe brevemente lo que pasó.");
      return;
    }
    // Los datos del observador nunca se usan como si fuera el afectado
    const afectado = rol === "observador"
      ? conoce
        ? { conocido: true, nombre: afNombre.trim(), edad: afEdad.trim(), cedula: afCedula.trim() }
        : { conocido: false }
      : undefined;
    setEnviando(true);
    setError(null);
    try {
      await enviarReporte({ ...datosPersona, rol, afectado, descripcion: descripcion.trim() });
      router.replace("/emergencia");
    } catch (err) {
      setError(err.message || "Sin conexión con el servidor. Intenta de nuevo.");
    } finally {
      setEnviando(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.fondo }}>
      <Cabecera atras titulo="Reportar emergencia" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={[e.cuerpo, { paddingBottom: insets.bottom + 28 }]} keyboardShouldPersistTaps="handled">
          {registrado ? (
            <View style={e.reportas}>
              <View style={e.reportasIcono}><Icono nombre="usuario" tamano={20} color={C.azul600} /></View>
              <View style={{ flex: 1 }}>
                <Text style={e.reportasEtiqueta}>REPORTAS COMO</Text>
                <Text style={e.reportasNombre}>{perfil.nombre}</Text>
                <Text style={e.reportasSub}>{[tipoTexto, perfil.edad ? `${perfil.edad} años` : null].filter(Boolean).join(" · ")}</Text>
              </View>
              <Icono nombre="check" tamano={20} color={C.ok} />
            </View>
          ) : (
            <Pressable onPress={() => router.push("/registro?editar=1")} style={e.sinRegistro} accessibilityRole="button">
              <Text style={e.sinRegistroTexto}>
                No estás registrado, así que necesitamos tus datos básicos. <Text style={{ fontFamily: F.negrita, color: C.azul700 }}>Regístrate</Text> para no escribirlos cada vez.
              </Text>
            </Pressable>
          )}

          {!registrado ? (<>
          <View style={e.grupo}>
            <Text style={e.etiqueta}>Soy parte de la comunidad USM como</Text>
            <View style={e.chips}>
              {TIPOS.map((t) => {
                const activo = tipoUsuario === t.valor;
                return (
                  <Pressable key={t.valor} onPress={() => setTipoUsuario(t.valor)} style={[e.chip, activo && e.chipActivo]} accessibilityRole="radio" accessibilityState={{ selected: activo }}>
                    <Text style={[e.chipTexto, activo && { color: "#fff" }]}>{t.texto}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          <View style={e.dos}>
            <View style={[e.grupo, { flex: 1 }]}>
              <Text style={e.etiqueta}>Nombre completo</Text>
              <TextInput style={e.input} value={nombre} onChangeText={setNombre} placeholder="Ej. María Pérez" placeholderTextColor="#9aa6bf" autoComplete="name" maxLength={80} />
            </View>
            <View style={[e.grupo, { width: 88 }]}>
              <Text style={e.etiqueta}>Edad</Text>
              <TextInput style={e.input} value={edad} onChangeText={(v) => setEdad(v.replace(/\D/g, ""))} placeholder="21" placeholderTextColor="#9aa6bf" keyboardType="number-pad" maxLength={3} />
            </View>
          </View>
          </>) : null}

          <View style={e.grupo}>
            <Text style={e.etiqueta}>¿Quién necesita ayuda?</Text>
            <View style={e.segmento}>
              {[["afectado", "Yo", "Soy el afectado"], ["observador", "Otra persona", "Soy observador"]].map(([valor, titulo, sub]) => {
                const activo = rol === valor;
                return (
                  <Pressable key={valor} onPress={() => setRol(valor)} style={[e.seg, activo && e.segActivo]} accessibilityRole="radio" accessibilityState={{ selected: activo }}>
                    <Text style={e.segTitulo}>{titulo}</Text>
                    <Text style={e.segSub}>{sub}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {rol === "observador" ? (
            <View style={e.observador}>
              <Text style={e.etiqueta}>¿Conoces a la persona afectada?</Text>
              <View style={e.segmento}>
                {[[true, "Sí, la conozco"], [false, "No la conozco"]].map(([valor, titulo]) => {
                  const activo = conoce === valor;
                  return (
                    <Pressable key={titulo} onPress={() => setConoce(valor)} style={[e.seg, e.segCorto, activo && e.segActivo]} accessibilityRole="radio" accessibilityState={{ selected: activo }}>
                      <Text style={e.segTitulo}>{titulo}</Text>
                    </Pressable>
                  );
                })}
              </View>
              {conoce ? (
                <>
                  <Text style={e.ayudaObs}>
                    Si la persona está consciente, pregúntale. Si está registrada en SOS USM, los bomberos recibirán su ficha médica (tú no verás esos datos).
                  </Text>
                  <View style={e.grupo}>
                    <Text style={e.etiqueta}>Nombre y apellido</Text>
                    <TextInput style={e.input} value={afNombre} onChangeText={setAfNombre} placeholder="Ej. Carlos Mendoza" placeholderTextColor="#9aa6bf" maxLength={80} />
                  </View>
                  <View style={e.dos}>
                    <View style={[e.grupo, { width: 88 }]}>
                      <Text style={e.etiqueta}>Edad</Text>
                      <TextInput style={e.input} value={afEdad} onChangeText={(v) => setAfEdad(v.replace(/\D/g, ""))} placeholder="21" placeholderTextColor="#9aa6bf" keyboardType="number-pad" maxLength={3} />
                    </View>
                    <View style={[e.grupo, { flex: 1 }]}>
                      <Text style={e.etiqueta}>Cédula <Text style={e.opcional}>(si la sabes)</Text></Text>
                      <TextInput style={e.input} value={afCedula} onChangeText={(v) => setAfCedula(v.replace(/[^\dVvEe-]/g, "").toUpperCase())} placeholder="V-27888999" placeholderTextColor="#9aa6bf" autoCapitalize="characters" maxLength={14} />
                    </View>
                  </View>
                </>
              ) : null}
            </View>
          ) : null}

          <View style={e.grupo}>
            <Text style={e.etiqueta}>Describe brevemente lo que pasó</Text>
            <TextInput
              style={[e.input, e.area]}
              value={descripcion}
              onChangeText={setDescripcion}
              placeholder="Qué ocurrió, dónde estás y cuántas personas están afectadas"
              placeholderTextColor="#9aa6bf"
              multiline
              maxLength={1000}
              textAlignVertical="top"
            />
            <View style={e.sugerencias}>
              {SUGERENCIAS.map(([t, frase]) => (
                <Pressable key={t} onPress={() => setDescripcion(frase + descripcion)} style={e.sug}>
                  <Text style={e.sugTexto}>{t}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          {error ? <Text style={e.error}>{error}</Text> : null}
          <BotonPrimario texto="Enviar reporte" icono="enviar" onPress={enviar} cargando={enviando} />
          <Text style={e.nota}>Tu ubicación GPS se adjunta automáticamente.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const e = StyleSheet.create({
  cuerpo: { padding: 16, gap: 18 },
  grupo: { gap: 8 },
  reportas: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#fff", borderRadius: 18, padding: 14, borderWidth: 1.5, borderColor: C.azul100 },
  reportasIcono: { width: 42, height: 42, borderRadius: 14, backgroundColor: C.azul50, alignItems: "center", justifyContent: "center" },
  reportasEtiqueta: { fontFamily: F.negrita, fontSize: 10, color: C.suave, letterSpacing: 0.8 },
  reportasNombre: { fontFamily: F.extra, fontSize: 16, color: C.texto, marginTop: 1 },
  reportasSub: { fontFamily: F.regular, fontSize: 13, color: C.suave },
  observador: { gap: 10, backgroundColor: "#fff", borderRadius: 16, padding: 14, borderWidth: 1.5, borderColor: C.azul100 },
  segCorto: { paddingVertical: 11, alignItems: "center" },
  ayudaObs: { fontFamily: F.regular, fontSize: 12, color: C.suave, lineHeight: 17 },
  opcional: { fontFamily: F.regular, color: C.suave, fontSize: 12 },
  sinRegistro: { backgroundColor: C.azul50, borderRadius: 14, padding: 12 },
  sinRegistroTexto: { fontFamily: F.regular, fontSize: 13, color: C.texto, lineHeight: 19 },
  etiqueta: { fontFamily: F.negrita, fontSize: 13, color: C.texto },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: "#fff", borderWidth: 1.5, borderColor: C.borde },
  chipActivo: { backgroundColor: C.azul600, borderColor: C.azul600 },
  chipTexto: { fontFamily: F.semi, fontSize: 14, color: C.texto },
  dos: { flexDirection: "row", gap: 10 },
  input: { fontFamily: F.medio, fontSize: 16, color: C.texto, backgroundColor: "#fff", borderWidth: 1.5, borderColor: C.borde, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12 },
  area: { minHeight: 110 },
  segmento: { flexDirection: "row", gap: 10 },
  seg: { flex: 1, padding: 12, borderRadius: 14, borderWidth: 1.5, borderColor: C.borde, backgroundColor: "#fff" },
  segActivo: { borderColor: C.azul600, backgroundColor: C.azul50, borderWidth: 2 },
  segTitulo: { fontFamily: F.negrita, fontSize: 15, color: C.texto },
  segSub: { fontFamily: F.regular, fontSize: 12, color: C.suave, marginTop: 2 },
  sugerencias: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  sug: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, backgroundColor: C.azul50, borderWidth: 1, borderStyle: "dashed", borderColor: C.azul100 },
  sugTexto: { fontFamily: F.semi, fontSize: 12, color: C.azul700 },
  error: { fontFamily: F.medio, fontSize: 14, color: C.peligro, textAlign: "center" },
  nota: { fontFamily: F.regular, fontSize: 12, color: C.suave, textAlign: "center", marginTop: -8 },
});
