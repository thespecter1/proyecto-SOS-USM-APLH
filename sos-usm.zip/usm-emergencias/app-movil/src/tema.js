// Identidad visual de SOS USM: azul y blanco. El rojo se reserva para alta prioridad.
import Constants from "expo-constants";
import appJson from "../app.json";

// Configuración de app.json (expo.extra). Se lee también del archivo por si el
// entorno no expone Constants.expoConfig (por ejemplo, en la versión web de pruebas).
const EXTRA = { ...appJson.expo.extra, ...(Constants.expoConfig?.extra || {}) };

export const C = {
  azul900: "#0a1f4d",
  azul800: "#0d2b6b",
  azul700: "#0f3c9e",
  azul600: "#1554d1",
  azul500: "#2f6bea",
  azul100: "#dce7ff",
  azul50: "#eef4ff",
  blanco: "#ffffff",
  fondo: "#f5f8fe",
  texto: "#0f1b33",
  suave: "#5b6b8a",
  borde: "#e2e9f5",
  peligro: "#d92d3a",
  peligroClaro: "#e5414d",
  peligroOscuro: "#a5161f",
  peligroBorde: "#f4c3c7",
  aviso: "#9a5b00",
  aviso50: "#fff6e5",
  ok: "#0f9d58",
  ok50: "#e5f6ed",
};

export const F = {
  regular: "PlusJakartaSans_400Regular",
  medio: "PlusJakartaSans_500Medium",
  semi: "PlusJakartaSans_600SemiBold",
  negrita: "PlusJakartaSans_700Bold",
  extra: "PlusJakartaSans_800ExtraBold",
};

export const SOMBRA = { boxShadow: "0px 8px 24px rgba(10, 31, 77, 0.10)" };

// Dirección del servidor (backend Node.js). Se puede definir con la variable
// EXPO_PUBLIC_SERVIDOR o en app.json → expo.extra.servidor
export const SERVIDOR =
  process.env.EXPO_PUBLIC_SERVIDOR || EXTRA.servidor || "http://localhost:3000";

// Teléfono de la central de Bomberos Universitarios: para llamar o enviar SMS
// cuando no hay internet (las llamadas y los SMS solo necesitan señal telefónica).
export const TELEFONO_BOMBEROS =
  process.env.EXPO_PUBLIC_TELEFONO_BOMBEROS || EXTRA.telefonoBomberos || "";
