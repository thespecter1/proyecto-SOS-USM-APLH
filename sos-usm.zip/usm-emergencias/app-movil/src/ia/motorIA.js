// ============================================================================
//  Motor de IA de SOS USM – funciona SIN INTERNET, dentro del teléfono.
//
//  Dos etapas:
//   1. Clasificador de texto Naive Bayes multinomial (aprendizaje automático),
//      entrenado con frases de ejemplo en español venezolano, que identifica el
//      tipo de emergencia a partir de la descripción.
//   2. Sistema experto (reglas) que fija la severidad y la prioridad, y genera
//      recomendaciones de primeros auxilios adaptadas al rol (afectado u
//      observador), a la edad y a la ficha médica registrada.
//
//  Está escrito en JavaScript sin dependencias (CommonJS) para que lo usen
//  tanto la app React Native como el servidor Node.js.
// ============================================================================

const VERSION = "1.0";

// ---------------------------------------------------------------------------
//  Base de conocimiento: clases, ejemplos de entrenamiento y protocolos
// ---------------------------------------------------------------------------
const CLASES = {
  incendio: {
    categoria: "incendio",
    subtipo: "Incendio / humo",
    severidad: "alta",
    recursos: ["Unidad contra incendios", "Extintores", "Equipo de evacuación"],
    claves: ["fuego", "incendio", "llama", "humo", "incendi", "ardiendo", "explot", "explosion", "prendio fuego", "se prendio", "se quema el", "se esta quemando"],
    ejemplos: [
      "hay fuego en el salon", "se esta quemando el laboratorio", "sale mucho humo del edificio",
      "hay un incendio en la cafeteria", "se prendio fuego la papelera", "huele a quemado y hay humo",
      "las llamas estan saliendo por la ventana", "exploto algo y hay fuego", "se incendio un carro en el estacionamiento",
      "hay humo negro en el pasillo", "se quema la cocina de la cafeteria", "hay un conato de incendio en el aula",
      "se prendio un cable y hay llamas", "el humo no deja ver en el piso", "esta ardiendo el deposito",
    ],
    recomendaciones: {
      afectado: [
        "Aléjate del fuego y del humo de inmediato; no regreses por tus pertenencias.",
        "Si hay humo, desplázate agachado y cúbrete nariz y boca con un paño (húmedo si es posible).",
        "No uses ascensores; baja por las escaleras siguiendo la ruta de evacuación.",
        "Si tu ropa se prende: detente, tírate al suelo y rueda.",
        "Ve al punto de encuentro y espera a los Bomberos Universitarios.",
      ],
      observador: [
        "Activa la alarma más cercana y avisa a las personas a tu alrededor.",
        "Usa un extintor solo si el fuego es pequeño y tienes una salida a tu espalda.",
        "Evacúa sin correr, sin usar ascensores, y cierra las puertas al salir.",
        "No vuelvas a entrar; indica a los bomberos si hay personas atrapadas.",
      ],
    },
  },
  cardiaca: {
    categoria: "medica",
    subtipo: "Emergencia cardíaca",
    severidad: "critica",
    recursos: ["Paramédicos", "DEA (desfibrilador)", "Ambulancia"],
    claves: ["pecho", "infarto", "corazon", "paro cardiaco", "palpitaciones", "brazo izquierdo"],
    ejemplos: [
      "me duele mucho el pecho", "le duele el pecho y el brazo izquierdo", "creo que le esta dando un infarto",
      "tiene dolor en el pecho y suda frio", "le dio un paro cardiaco", "siento presion en el pecho",
      "el profesor se agarra el pecho y no puede hablar", "tengo palpitaciones muy fuertes", "el corazon me late muy rapido y me duele",
      "se desplomo agarrandose el pecho", "tiene dolor en el pecho que le baja al brazo", "le esta fallando el corazon",
    ],
    recomendaciones: {
      afectado: [
        "Detén toda actividad y siéntate o recuéstate en un lugar seguro.",
        "Afloja la ropa ajustada y respira con calma.",
        "Pide a alguien cercano que se quede contigo hasta que llegue la ayuda.",
        "No camines ni subas escaleras; espera a los paramédicos.",
      ],
      observador: [
        "Mantén a la persona en reposo, sentada o recostada, y no la dejes sola.",
        "Si pierde el conocimiento y no respira, inicia RCP: 30 compresiones fuertes y rápidas en el centro del pecho.",
        "Pide que traigan el DEA (desfibrilador) más cercano y sigue sus instrucciones de voz.",
        "No le des comida ni bebida.",
      ],
    },
  },
  respiratoria: {
    categoria: "medica",
    subtipo: "Dificultad respiratoria",
    severidad: "critica",
    recursos: ["Paramédicos", "Oxígeno", "Ambulancia"],
    claves: ["no respira", "no puede respirar", "respirar", "ahoga", "asma", "asfixia", "atragant", "se ahoga", "falta de aire"],
    ejemplos: [
      "no puede respirar", "se esta ahogando", "le dio un ataque de asma", "se atraganto con comida",
      "le falta el aire", "no respira bien y esta morado", "tiene una crisis de asma y no tiene inhalador",
      "me cuesta respirar", "se atoro con algo y no puede hablar", "respira muy rapido y con silbido",
      "siente que se asfixia", "tiene los labios morados y no respira",
    ],
    recomendaciones: {
      afectado: [
        "Siéntate erguido e inclínate un poco hacia adelante.",
        "Si tienes inhalador, úsalo ahora.",
        "Respira lento: inhala por la nariz y exhala por la boca.",
        "Busca un lugar ventilado, lejos del humo o el polvo.",
      ],
      observador: [
        "Si se atraganta y no puede hablar ni toser, aplica la maniobra de Heimlich.",
        "Ayuda a la persona a sentarse erguida y aflójale la ropa.",
        "Si deja de respirar, inicia RCP y pide el DEA.",
        "Mantén el área despejada y ventilada.",
      ],
    },
  },
  inconsciencia: {
    categoria: "medica",
    subtipo: "Pérdida de conocimiento / convulsión",
    severidad: "alta",
    recursos: ["Paramédicos", "Ambulancia"],
    claves: ["desmay", "inconsciente", "convuls", "no reacciona", "no responde", "epilep", "yeyo", "se desvanecio", "perdio el conocimiento"],
    ejemplos: [
      "se desmayo en el pasillo", "esta inconsciente en el piso", "le dio un yeyo", "esta convulsionando",
      "no reacciona cuando le hablo", "se cayo al piso y no responde", "le dio un ataque de epilepsia",
      "perdio el conocimiento en clase", "se desvanecio de repente", "esta tirado en el suelo sin moverse",
      "se le pusieron los ojos en blanco y se cayo", "me estoy desmayando",
    ],
    recomendaciones: {
      afectado: [
        "Si te sientes mareado, acuéstate en el suelo y eleva las piernas.",
        "No te levantes de golpe.",
        "Avisa a alguien cercano para que te acompañe.",
      ],
      observador: [
        "Comprueba si responde y si respira.",
        "Si respira, colócala de lado (posición lateral de seguridad).",
        "Si convulsiona: retira objetos cercanos, protege su cabeza y NO le metas nada en la boca.",
        "Si no respira, inicia RCP y pide el DEA.",
      ],
    },
  },
  trauma: {
    categoria: "trauma",
    subtipo: "Traumatismo / herida",
    severidad: "moderada",
    recursos: ["Paramédicos", "Kit de trauma", "Camilla"],
    claves: ["caida", "cayo", "cai", "fractura", "golpe", "sangr", "herida", "corte", "hueso", "esguince", "tobillo", "accidente", "atropell", "choque", "escalera"],
    ejemplos: [
      "se cayo por las escaleras", "me cai y me duele el tobillo", "se golpeo la cabeza", "tiene una herida que sangra mucho",
      "se corto la mano con un vidrio", "creo que se fracturo el brazo", "lo atropello un carro en la entrada",
      "choque de motos en el estacionamiento", "se torcio el pie jugando", "tiene el hueso salido",
      "se resbalo y no se puede levantar", "le cayo algo pesado encima", "esta sangrando por la nariz y la cabeza",
    ],
    recomendaciones: {
      afectado: [
        "No te muevas si sientes dolor en el cuello o la espalda.",
        "Presiona la herida con un paño limpio para detener el sangrado.",
        "No intentes enderezar una extremidad deformada.",
        "Mantente abrigado y en calma hasta que llegue la ayuda.",
      ],
      observador: [
        "No muevas a la persona salvo que esté en peligro inmediato.",
        "Aplica presión directa y firme sobre la herida con un paño limpio.",
        "Inmoviliza la zona lesionada tal como está.",
        "Mantén a la persona consciente, hablándole y abrigada.",
      ],
    },
  },
  quemadura: {
    categoria: "trauma",
    subtipo: "Quemadura",
    severidad: "moderada",
    recursos: ["Paramédicos", "Kit de quemaduras"],
    claves: ["quemadura", "me queme", "se quemo", "agua hirviendo", "aceite caliente", "ampolla"],
    ejemplos: [
      "me queme la mano con aceite caliente", "se quemo con agua hirviendo", "tiene una quemadura en el brazo",
      "le salieron ampollas por una quemadura", "se quemo con un acido en el laboratorio", "me cayo cafe hirviendo encima",
      "se quemo la cara con el mechero", "tiene la piel roja y quemada",
    ],
    recomendaciones: {
      afectado: [
        "Enfría la quemadura con agua corriente (no helada) durante 10 a 20 minutos.",
        "Quítate anillos, relojes o ropa cerca de la zona, salvo que estén pegados a la piel.",
        "No revientes las ampollas ni apliques pasta dental, aceite ni hielo.",
        "Cubre la zona con un paño limpio y húmedo.",
      ],
      observador: [
        "Aleja a la persona de la fuente de calor.",
        "Enfría la quemadura con agua corriente durante 10 a 20 minutos.",
        "No reventar ampollas ni aplicar remedios caseros.",
        "Cubre con un paño limpio y vigila que respire bien si la quemadura es en la cara.",
      ],
    },
  },
  alergia: {
    categoria: "medica",
    subtipo: "Reacción alérgica",
    severidad: "alta",
    recursos: ["Paramédicos", "Epinefrina", "Ambulancia"],
    claves: ["alergi", "anafila", "ronchas", "se hincho", "hinchazon", "picadura", "abeja", "urticaria"],
    ejemplos: [
      "le dio una reaccion alergica", "se le hincho la cara despues de comer", "lo pico una abeja y se esta hinchando",
      "tiene ronchas en todo el cuerpo", "es alergico al mani y comio", "se le esta cerrando la garganta por alergia",
      "tiene la boca y los ojos hinchados", "le dio urticaria y le pica todo",
    ],
    recomendaciones: {
      afectado: [
        "Si tienes autoinyector de epinefrina (EpiPen), úsalo ahora en el muslo.",
        "Aléjate de lo que causó la reacción (comida, insecto, sustancia).",
        "Siéntate erguido si te cuesta respirar; acuéstate con las piernas elevadas si te mareas.",
        "Si tienes antialérgico indicado por tu médico, tómalo.",
      ],
      observador: [
        "Pregunta si tiene autoinyector de epinefrina y ayúdale a usarlo.",
        "Aleja a la persona de lo que causó la reacción.",
        "Vigila su respiración; si deja de respirar, inicia RCP.",
        "No le des comida ni bebida.",
      ],
    },
  },
  gas_quimico: {
    categoria: "fuga_gas_quimico",
    subtipo: "Fuga de gas / derrame químico",
    severidad: "alta",
    recursos: ["Unidad HAZMAT", "Equipo de evacuación", "Ventilación"],
    claves: ["gas", "olor a gas", "quimic", "derrame", "toxic", "vapor", "reactivo", "acido"],
    ejemplos: [
      "huele mucho a gas", "hay una fuga de gas en la cafeteria", "se derramo un quimico en el laboratorio",
      "hay vapores toxicos", "se rompio un frasco de reactivo", "huele raro y nos esta picando la garganta",
      "se escapa gas de la bombona", "se derramo acido en el mesón", "hay un olor fuerte a quimicos",
    ],
    recomendaciones: {
      afectado: [
        "Sal del área de inmediato hacia un lugar ventilado.",
        "No enciendas ni apagues interruptores, ni uses encendedores.",
        "Si un químico te tocó la piel o los ojos, lávate con abundante agua durante 15 minutos.",
        "Cúbrete nariz y boca, y no comas ni bebas nada.",
      ],
      observador: [
        "Evacúa a las personas del área sin activar aparatos eléctricos.",
        "Abre puertas y ventanas solo si es seguro hacerlo al salir.",
        "No toques ni intentes limpiar el derrame.",
        "Si puedes, identifica el nombre del producto para los bomberos.",
      ],
    },
  },
  estructural: {
    categoria: "estructural",
    subtipo: "Daño estructural / sismo",
    severidad: "alta",
    recursos: ["Rescate estructural", "Equipo de evacuación", "Paramédicos"],
    claves: ["derrumb", "colaps", "grieta", "sismo", "temblor", "terremoto", "atrapad", "escombro", "se cayo el techo", "se cayo una pared"],
    ejemplos: [
      "se derrumbo una pared", "esta temblando", "hubo un terremoto", "hay personas atrapadas en los escombros",
      "se cayo parte del techo", "hay grietas grandes en la columna", "colapso la escalera",
      "quedamos atrapados en el ascensor", "se desplomo el techo del salon", "hay un sismo fuerte",
    ],
    recomendaciones: {
      afectado: [
        "Si estás atrapado, cúbrete boca y nariz y golpea tuberías o paredes para que te ubiquen.",
        "Usa la linterna del teléfono y ahorra batería.",
        "Si puedes salir, aléjate de ventanas, paredes dañadas y cables.",
        "Ve a un espacio abierto y seguro.",
      ],
      observador: [
        "No entres a estructuras dañadas.",
        "Aleja a las personas del área afectada y de posibles réplicas.",
        "Indica a los bomberos la ubicación exacta de posibles atrapados.",
        "Mantén despejadas las vías de acceso.",
      ],
    },
  },
  electrica: {
    categoria: "electrica",
    subtipo: "Riesgo eléctrico",
    severidad: "alta",
    recursos: ["Unidad de rescate", "Mantenimiento eléctrico", "Paramédicos"],
    claves: ["electric", "cortocircuito", "cable", "chispa", "corriente", "electrocut", "tablero", "descarga"],
    ejemplos: [
      "le dio corriente", "hay un cortocircuito en el tablero", "un cable pelado esta echando chispas",
      "se electrocuto un obrero", "recibio una descarga electrica", "hay cables caidos en el agua",
      "salen chispas del enchufe", "esta pegado a la corriente",
    ],
    recomendaciones: {
      afectado: [
        "Aléjate de cables, charcos y equipos eléctricos.",
        "Si recibiste una descarga, no te muevas bruscamente y espera la evaluación médica.",
        "No toques a otras personas que estén en contacto con la corriente.",
      ],
      observador: [
        "NO toques a la persona si sigue en contacto con la corriente.",
        "Corta la energía desde el tablero solo si es seguro hacerlo.",
        "Usa un objeto seco y no conductor (madera, plástico) para separar a la víctima.",
        "Si no respira, inicia RCP cuando ya no haya riesgo eléctrico.",
      ],
    },
  },
  seguridad: {
    categoria: "seguridad",
    subtipo: "Incidente de seguridad",
    severidad: "alta",
    recursos: ["Seguridad universitaria", "Policía", "Paramédicos"],
    claves: ["robo", "robaron", "asalt", "arma", "pistola", "cuchillo", "pelea", "agresi", "amenaz", "violen", "disparo", "tiro", "acoso", "atraco"],
    ejemplos: [
      "me robaron el telefono", "hay una pelea en la cafeteria", "un hombre armado esta amenazando", "se escucharon disparos",
      "estan asaltando en la parada", "me estan acosando", "le pegaron a un estudiante", "hay un tipo con un cuchillo",
      "atracaron a una profesora en el estacionamiento", "hay una persona sospechosa siguiendome", "hubo un tiroteo afuera",
    ],
    recomendaciones: {
      afectado: [
        "Prioriza tu vida: no te resistas ni enfrentes al agresor.",
        "Busca un lugar seguro con otras personas; cierra con llave si puedes.",
        "Pon el teléfono en silencio y usa el chat para comunicarte.",
        "Memoriza rasgos del agresor solo si es seguro.",
      ],
      observador: [
        "No intervengas directamente; mantén una distancia segura.",
        "Aléjate y guía a otros hacia un lugar seguro.",
        "Reporta por el chat: número de personas, descripción y dirección de huida.",
      ],
    },
  },
  malestar: {
    categoria: "medica",
    subtipo: "Malestar general",
    severidad: "baja",
    recursos: ["Enfermería / primeros auxilios"],
    claves: ["mareo", "mareado", "fiebre", "vomit", "nausea", "dolor de cabeza", "dolor de barriga", "tension", "presion alta", "azucar", "debil"],
    ejemplos: [
      "me siento mareado", "tengo mucha fiebre", "estoy vomitando", "tengo un dolor de cabeza muy fuerte",
      "me duele mucho la barriga", "me subio la tension", "le bajo el azucar", "me siento debil y con nauseas",
      "tengo la presion alta", "me duele el estomago desde la manana", "estoy temblando de fiebre",
    ],
    recomendaciones: {
      afectado: [
        "Siéntate o acuéstate en un lugar fresco y tranquilo.",
        "Toma agua a sorbos pequeños si no tienes náuseas.",
        "Si tomas algún medicamento indicado para esto, tómalo según tu tratamiento.",
        "Avisa en el chat si los síntomas empeoran.",
      ],
      observador: [
        "Ayuda a la persona a sentarse o acostarse en un lugar fresco.",
        "Ofrécele agua a sorbos si está consciente y no vomita.",
        "Quédate con ella y avisa en el chat si empeora o pierde el conocimiento.",
      ],
    },
  },
  crisis_emocional: {
    categoria: "medica",
    subtipo: "Crisis de ansiedad / emocional",
    severidad: "moderada",
    recursos: ["Orientación / psicología", "Enfermería"],
    claves: ["ansiedad", "ataque de panico", "crisis nerviosa", "llorando", "no puedo calmarme", "me quiero morir", "suicid", "hacerse dano"],
    ejemplos: [
      "tengo un ataque de ansiedad", "estoy teniendo un ataque de panico", "no puede parar de llorar y temblar",
      "le dio una crisis nerviosa", "no me puedo calmar", "un estudiante dice que se quiere hacer dano",
      "siento que me voy a morir de la ansiedad", "esta muy alterado y respira rapido por nervios",
    ],
    recomendaciones: {
      afectado: [
        "Busca un lugar tranquilo y siéntate.",
        "Respira lento: inhala en 4 segundos, sostén 4 y exhala en 6. Repite varias veces.",
        "Nombra 5 cosas que ves y 4 que puedes tocar para enfocarte en el presente.",
        "No estás solo: la ayuda va en camino y puedes escribir en el chat.",
      ],
      observador: [
        "Acompaña a la persona en un lugar tranquilo y háblale con calma.",
        "No la juzgues ni la presiones; escúchala.",
        "Ayúdala a respirar lento contigo.",
        "Si menciona hacerse daño, no la dejes sola y avisa en el chat de inmediato.",
      ],
    },
  },
};

// Protocolo de regla (no aprendido): persona inconsciente que no respira = posible paro cardiorrespiratorio
const PARO = {
  categoria: "medica",
  subtipo: "Posible paro cardiorrespiratorio",
  severidad: "critica",
  recursos: ["Paramédicos", "DEA (desfibrilador)", "Ambulancia"],
  recomendaciones: {
    afectado: [
      "Pide a la persona más cercana que lea estas instrucciones y te ayude.",
      "Acuéstate boca arriba en el suelo y no te muevas.",
      "La ayuda va en camino con un desfibrilador (DEA).",
    ],
    observador: [
      "Inicia RCP ya: coloca las manos en el centro del pecho y comprime fuerte y rápido (100 a 120 por minuto).",
      "Si sabes hacerlo, da 2 ventilaciones cada 30 compresiones; si no, solo compresiones sin parar.",
      "Pide a alguien que traiga el DEA más cercano y sigue sus instrucciones de voz.",
      "No te detengas hasta que la persona respire o lleguen los Bomberos Universitarios.",
    ],
  },
};

const GENERICO = {
  categoria: "otro",
  subtipo: "Emergencia no especificada",
  severidad: "moderada",
  recursos: ["Unidad de primera respuesta"],
  recomendaciones: {
    afectado: [
      "Mantén la calma y ubícate en un lugar seguro.",
      "Permanece donde estás si es seguro; los bomberos tienen tu ubicación.",
      "Describe en el chat qué está pasando para orientarte mejor.",
    ],
    observador: [
      "Mantén una distancia segura y no te expongas a riesgos.",
      "Acompaña al afectado y mantenlo tranquilo.",
      "Describe en el chat qué está pasando para orientarte mejor.",
    ],
  },
};

// Señales que elevan la severidad a crítica, sin importar la clase
const SENALES_CRITICAS = [
  "no respira", "inconsciente", "no reacciona", "no responde", "mucha sangre", "sangra mucho", "sangrando mucho", "atrapad", "arma", "pistola",
  "disparo", "tiroteo", "explot", "paro", "varios heridos", "muchas personas", "morado", "se quiere hacer dano",
  "suicid", "se esta cerrando la garganta", "hueso salido",
];

const NIVELES = ["baja", "moderada", "alta", "critica"];
const PRIORIDAD = { baja: 2, moderada: 3, alta: 4, critica: 5 };

// ---------------------------------------------------------------------------
//  Procesamiento de lenguaje natural
// ---------------------------------------------------------------------------
const PALABRAS_VACIAS = new Set(
  ("a al algo alguien ante con contra de del desde el ella ellos en entre es esta estan este esto hay la las le les lo los me mi mis " +
    "muy nos o para pero por que se si sin sobre su sus te tiene tengo un una uno unos unas y ya yo ahi aqui alla esa ese eso como cuando " +
    "donde fue ha han hace estoy estamos esta").split(" ")
);

function normalizar(t = "") {
  return String(t).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9ñ\s]/g, " ").replace(/\s+/g, " ").trim();
}

// Stemmer ligero para español: quita sufijos verbales y nominales frecuentes
// ("robando", "robaron", "robo" → "rob") y unifica qu/c y gu/g ("choque" ~ "chocó").
const SUFIJOS = [
  "amientos", "imientos", "amiento", "imiento", "aciones", "uciones", "acion", "ucion",
  "ando", "iendo", "aron", "ieron", "aban", "aste", "iste", "ados", "adas", "idos", "idas",
  "ado", "ada", "ido", "ida", "aba", "ar", "er", "ir", "as", "es", "an", "en", "os", "a", "o", "e", "s",
];
function raiz(palabra) {
  let p = palabra.replace(/qu/g, "c").replace(/gu(?=[ei])/g, "g");
  for (let vuelta = 0; vuelta < 2; vuelta++) {
    const s = SUFIJOS.find((x) => p.endsWith(x) && p.length - x.length >= 3);
    if (!s) break;
    p = p.slice(0, -s.length);
  }
  return p.slice(0, 6);
}

function tokenizar(texto) {
  const palabras = normalizar(texto).split(" ").filter(Boolean);
  const tokens = [];
  for (let i = 0; i < palabras.length; i++) {
    const p = palabras[i];
    if (p === "no" && palabras[i + 1]) tokens.push("no_" + raiz(palabras[i + 1])); // negaciones: "no respira"
    if (!PALABRAS_VACIAS.has(p) && p.length > 1) tokens.push(raiz(p));
  }
  return tokens;
}

function contiene(textoNormalizado, clave) {
  const c = normalizar(clave).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp("(^|[^a-z])" + c).test(textoNormalizado);
}

// ---------------------------------------------------------------------------
//  Clasificador Naive Bayes multinomial (se entrena al cargar el módulo)
// ---------------------------------------------------------------------------
function entrenar() {
  const modelo = { clases: {}, vocabulario: new Set(), totalDocs: 0 };
  for (const [nombre, c] of Object.entries(CLASES)) {
    const conteo = {};
    let total = 0;
    // Los ejemplos y las palabras clave son los datos de entrenamiento
    const docs = [...c.ejemplos, ...c.claves];
    for (const doc of docs) {
      for (const tok of tokenizar(doc)) {
        conteo[tok] = (conteo[tok] || 0) + 1;
        total++;
        modelo.vocabulario.add(tok);
      }
    }
    modelo.clases[nombre] = { conteo, total, docs: docs.length };
    modelo.totalDocs += docs.length;
  }
  return modelo;
}
const MODELO = entrenar();

function clasificarNB(texto) {
  const tokens = tokenizar(texto);
  const V = MODELO.vocabulario.size;
  const puntajes = {};
  for (const [nombre, c] of Object.entries(MODELO.clases)) {
    let lp = Math.log(c.docs / MODELO.totalDocs);
    for (const t of tokens) lp += Math.log(((c.conteo[t] || 0) + 1) / (c.total + V)); // suavizado de Laplace
    puntajes[nombre] = lp;
  }
  const conocidos = tokens.filter((t) => MODELO.vocabulario.has(t)).length;
  return { puntajes, conocidos, tokens };
}

// ---------------------------------------------------------------------------
//  Análisis completo (Naive Bayes + sistema experto)
// ---------------------------------------------------------------------------
function analizarEmergencia({ descripcion = "", rol = "afectado", edad, perfil } = {}) {
  const texto = normalizar(descripcion);
  const quien = rol === "observador" ? "observador" : "afectado";
  const { puntajes, conocidos } = clasificarNB(descripcion);

  // Combinar probabilidad del modelo con evidencia de palabras clave (sistema experto)
  const combinados = {};
  for (const [nombre, c] of Object.entries(CLASES)) {
    const aciertos = c.claves.filter((k) => contiene(texto, k)).length;
    combinados[nombre] = puntajes[nombre] + aciertos * 3;
  }
  const orden = Object.entries(combinados).sort((a, b) => b[1] - a[1]);
  const max = orden[0][1];
  const exp = orden.map(([n, v]) => [n, Math.exp(v - max)]);
  const suma = exp.reduce((s, [, v]) => s + v, 0);
  const confianza = exp[0][1] / suma;
  const ganadora = orden[0][0];

  // Si el texto no tiene palabras conocidas o la confianza es muy baja: emergencia genérica
  const hayClaves = CLASES[ganadora].claves.some((k) => contiene(texto, k));
  let clase = conocidos === 0 || (confianza < 0.2 && !hayClaves) ? GENERICO : CLASES[ganadora];
  // Regla del sistema experto con prioridad sobre el clasificador
  const noRespira = ["no respira", "dejo de respirar", "sin respirar"].some((k) => contiene(texto, k));
  const inconsciente = ["desmay", "inconsciente", "no responde", "no reacciona", "se desplomo", "cayo al piso", "yeyo"].some((k) => contiene(texto, k));
  const cardiaco = clase === CLASES.cardiaca || ["pecho", "infarto", "corazon"].some((k) => contiene(texto, k));
  if (noRespira && (inconsciente || cardiaco)) clase = PARO;

  // --- Severidad ---
  let severidad = clase.severidad;
  const factores = [];
  if (SENALES_CRITICAS.some((s) => contiene(texto, s))) {
    severidad = "critica";
    factores.push("indicadores de riesgo vital en la descripción");
  }
  const e = Number(edad || perfil?.edad);
  if (e && (e >= 60 || e <= 12) && severidad !== "critica") {
    severidad = NIVELES[Math.min(NIVELES.indexOf(severidad) + 1, 3)];
    factores.push(`persona vulnerable por edad (${e} años)`);
  }

  // --- Recomendaciones personalizadas con la ficha médica (solo si es el afectado) ---
  const recomendaciones = [...clase.recomendaciones[quien]];
  if (quien === "afectado" && perfil) {
    const cond = normalizar(perfil.condiciones);
    const alerg = normalizar(perfil.alergias);
    if (/asma/.test(cond) && clase === CLASES.respiratoria)
      recomendaciones.unshift("Tienes asma registrada: usa tu inhalador de rescate ahora.");
    if (/diabet/.test(cond) && (clase === CLASES.inconsciencia || clase === CLASES.malestar))
      recomendaciones.unshift("Tienes diabetes registrada: si puedes tragar, toma algo con azúcar (jugo o caramelo).");
    if (/(cardi|corazon|hipertens)/.test(cond) && clase === CLASES.cardiaca) {
      severidad = "critica";
      factores.push("antecedente cardíaco o de hipertensión registrado");
    }
    if (/epilep/.test(cond) && clase === CLASES.inconsciencia)
      recomendaciones.push("Tienes epilepsia registrada: los bomberos ya conocen tu condición.");
    if (alerg && clase === CLASES.alergia) {
      severidad = "critica";
      factores.push(`alergia registrada: ${perfil.alergias}`);
    }
  }

  return {
    categoria: clase.categoria,
    subtipo: clase.subtipo,
    severidad,
    prioridad: PRIORIDAD[severidad],
    resumen: `${clase.subtipo} reportada por ${quien}${e ? ` (${e} años)` : ""}.${factores.length ? " Factores: " + factores.join("; ") + "." : ""}`,
    recomendaciones: recomendaciones.slice(0, 5),
    recursos: clase.recursos,
    confianza: Math.round(confianza * 100),
    fuente: "dispositivo",
    modelo: `IA en el dispositivo v${VERSION} (Naive Bayes + sistema experto)`,
  };
}

// Alerta SOS: protocolo de máxima prioridad, con la ficha registrada si existe
function analisisSOS(perfil) {
  const ficha = perfil
    ? [
        `Persona registrada: ${perfil.nombre}${perfil.edad ? `, ${perfil.edad} años` : ""}`,
        perfil.sangre && perfil.sangre !== "No sé" ? `sangre ${perfil.sangre}` : "",
        perfil.condiciones ? `condiciones: ${perfil.condiciones}` : "",
        perfil.alergias ? `alergias: ${perfil.alergias}` : "",
        perfil.medicamentos ? `medicamentos: ${perfil.medicamentos}` : "",
      ].filter(Boolean).join("; ") + "."
    : "Sin perfil registrado.";
  return {
    categoria: "otro",
    subtipo: "ALERTA SOS · ALTA PRIORIDAD",
    severidad: "critica",
    prioridad: 5,
    resumen: `Alerta SOS de alta prioridad (riesgo inminente para la vida). Acudir de inmediato a la ubicación GPS. ${ficha}`,
    recomendaciones: [
      "La ayuda va en camino: los Bomberos Universitarios tienen tu ubicación.",
      "Si puedes, muévete a un lugar seguro y visible.",
      "Mantén el teléfono contigo y con la pantalla encendida.",
      "Si puedes escribir, usa el chat para decir qué ocurre.",
    ],
    recursos: ["Unidad de primera respuesta", "Paramédicos", "Seguridad universitaria"],
    fuente: "protocolo",
    modelo: "Protocolo SOS",
  };
}

module.exports = { analizarEmergencia, analisisSOS, tokenizar, clasificarNB, CLASES, VERSION };
