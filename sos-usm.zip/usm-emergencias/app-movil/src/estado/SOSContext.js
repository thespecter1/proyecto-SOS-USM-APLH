// ============================================================================
//  Estado global de SOS USM: dispositivo, perfil, GPS, conexión en tiempo real
//  (Socket.IO), emergencia activa y cola de envíos sin conexión.
//
//  Diseño "offline-first":
//   - La recomendación de la IA se calcula EN EL TELÉFONO (motorIA.js), sin internet.
//   - Si no hay conexión, la alerta se guarda en una cola y se reenvía sola
//     en cuanto vuelve la señal.
// ============================================================================
import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { Platform } from "react-native";
import * as Location from "expo-location";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { io } from "socket.io-client";
import { SERVIDOR } from "../tema";
import { analizarEmergencia, analisisSOS } from "../ia/motorIA";

const Contexto = createContext(null);
export const useSOS = () => useContext(Contexto);

const nuevoId = (prefijo = "dev") =>
  `${prefijo}-` + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);

// Perfil que la persona registra en un momento de calma
export const PERFIL_VACIO = {
  registrado: false,
  consentimiento: false,
  tipoUsuario: "estudiante",
  nombre: "",
  cedula: "",
  edad: "",
  telefono: "",
  carrera: "",
  sangre: "",
  alergias: "",
  condiciones: "",
  medicamentos: "",
  contactoNombre: "",
  contactoTelefono: "",
  contactoParentesco: "",
};

export function vibrar(tipo = "ligero") {
  if (Platform.OS === "web") return;
  try {
    if (tipo === "alerta") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    else if (tipo === "exito") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else Haptics.impactAsync(tipo === "fuerte" ? Haptics.ImpactFeedbackStyle.Heavy : Haptics.ImpactFeedbackStyle.Light);
  } catch {}
}

// fetch con tiempo límite: con mala señal no queremos esperar indefinidamente
async function pedir(ruta, opciones = {}, ms = 8000) {
  const control = new AbortController();
  const t = setTimeout(() => control.abort(), ms);
  try {
    return await fetch(`${SERVIDOR}${ruta}`, { ...opciones, signal: control.signal });
  } finally {
    clearTimeout(t);
  }
}
const postJSON = (ruta, cuerpo, ms) =>
  pedir(ruta, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(cuerpo) }, ms);

// Error de validación del servidor (no se debe reintentar)
class ErrorServidor extends Error {}

async function subirPerfil(deviceId, perfil) {
  const r = await postJSON("/api/perfil", { deviceId, perfil });
  const datos = await r.json().catch(() => ({}));
  if (!r.ok) throw new ErrorServidor(datos.error || "No se pudo registrar el perfil.");
  return datos.perfil;
}

export function SOSProvider({ children }) {
  const [deviceId, setDeviceId] = useState(null);
  const [ubicacion, setUbicacion] = useState(null);
  const [simulada, setSimulada] = useState(false);
  const [incidente, setIncidente] = useState(null);
  const [conectado, setConectado] = useState(false);
  const [sinSenal, setSinSenal] = useState(false); // sin conexión con la central por más de unos segundos
  const [perfil, setPerfil] = useState(PERFIL_VACIO);
  const [perfilCargado, setPerfilCargado] = useState(false);
  const [pendientes, setPendientes] = useState(0);

  const perfilRef = useRef(PERFIL_VACIO);
  const socketRef = useRef(null);
  const ubicRef = useRef(null);
  const incRef = useRef(null);
  const watchRef = useRef(null);
  const simRef = useRef(null);
  const ultimoEnvio = useRef(0);
  const campusRef = useRef({ lat: 10.4806, lng: -66.804 });
  const colaRef = useRef([]);
  const procesando = useRef(false);

  const fijarIncidente = useCallback((inc) => {
    incRef.current = inc;
    setIncidente(inc);
    AsyncStorage.setItem("sos_incidente_obj", inc ? JSON.stringify(inc) : "").catch(() => {});
  }, []);

  const guardarCola = useCallback((cola) => {
    colaRef.current = cola;
    setPendientes(cola.length);
    AsyncStorage.setItem("sos_cola", JSON.stringify(cola)).catch(() => {});
  }, []);

  // 1) Carga inicial: identificador, perfil, emergencia activa y cola pendiente
  useEffect(() => {
    (async () => {
      let id = await AsyncStorage.getItem("sos_device").catch(() => null);
      if (!id) {
        id = nuevoId();
        await AsyncStorage.setItem("sos_device", id).catch(() => {});
      }
      try {
        const p = await AsyncStorage.getItem("sos_perfil");
        if (p) {
          perfilRef.current = { ...PERFIL_VACIO, ...JSON.parse(p) };
          setPerfil(perfilRef.current);
        }
      } catch {}
      try {
        const inc = await AsyncStorage.getItem("sos_incidente_obj");
        if (inc) {
          const obj = JSON.parse(inc);
          if (obj && obj.estado !== "resuelto") { incRef.current = obj; setIncidente(obj); }
        }
      } catch {}
      try {
        const c = await AsyncStorage.getItem("sos_cola");
        if (c) { colaRef.current = JSON.parse(c) || []; setPendientes(colaRef.current.length); }
      } catch {}
      setPerfilCargado(true);
      setDeviceId(id);
    })();
  }, []);

  // 2) Envío de la cola pendiente (se llama al reconectar y periódicamente)
  const procesarCola = useCallback(async () => {
    if (procesando.current || !deviceId || colaRef.current.length === 0) return;
    procesando.current = true;
    try {
      for (const item of [...colaRef.current]) {
        try {
          const ruta = item.tipo === "sos" ? "/api/panico" : "/api/incidentes";
          const perfilEnvio = perfilRef.current.registrado ? perfilRef.current : undefined;
          const r = await postJSON(ruta, { deviceId, ...item.datos, ubicacion: ubicRef.current || item.datos.ubicacion, perfil: perfilEnvio });
          const inc = await r.json();
          if (!r.ok) throw new ErrorServidor(inc.error);
          guardarCola(colaRef.current.filter((x) => x.idLocal !== item.idLocal));
          // Si la emergencia en pantalla era la local, se reemplaza por la del servidor
          if (incRef.current?.id === item.idLocal) {
            const pendientesChat = incRef.current.mensajes.filter((m) => m.de === "usuario");
            fijarIncidente(inc);
            socketRef.current?.emit("incidente:unirse", inc.id);
            pendientesChat.forEach((m) => socketRef.current?.emit("chat:enviar", { incidenteId: inc.id, texto: m.texto }));
            vibrar("exito");
          }
        } catch (err) {
          if (err instanceof ErrorServidor) guardarCola(colaRef.current.filter((x) => x.idLocal !== item.idLocal));
          else break; // sigue sin conexión: se reintenta más tarde
        }
      }
    } finally {
      procesando.current = false;
    }
  }, [deviceId, fijarIncidente, guardarCola]);

  useEffect(() => {
    if (!deviceId) return;
    const t = setInterval(() => procesarCola(), 10000);
    return () => clearInterval(t);
  }, [deviceId, procesarCola]);

  // 3) Conexión en tiempo real con la central
  useEffect(() => {
    if (!deviceId) return;
    const s = io(SERVIDOR, { auth: { rol: "usuario", deviceId }, transports: ["websocket"], reconnectionDelayMax: 5000 });
    socketRef.current = s;
    let temporizador = setTimeout(() => setSinSenal(true), 5000);

    s.on("connect", () => {
      clearTimeout(temporizador);
      setConectado(true);
      setSinSenal(false);
      const actual = incRef.current;
      if (actual && !actual.local) s.emit("incidente:unirse", actual.id);
      if (ubicRef.current) s.emit("ubicacion", ubicRef.current);
      if (perfilRef.current.registrado) subirPerfil(deviceId, perfilRef.current).catch(() => {});
      procesarCola();
      // Recupera el estado más reciente de la emergencia activa
      if (actual && !actual.local) {
        pedir(`/api/incidentes/${actual.id}?deviceId=${encodeURIComponent(deviceId)}`)
          .then((r) => (r.ok ? r.json() : null))
          .then((inc) => inc && fijarIncidente(inc))
          .catch(() => {});
      }
    });
    s.on("disconnect", () => {
      setConectado(false);
      clearTimeout(temporizador);
      temporizador = setTimeout(() => setSinSenal(true), 5000);
    });
    s.on("incidente:actualizado", (inc) => {
      const actual = incRef.current;
      if (!actual || inc.id !== actual.id) return;
      if (inc.estado !== actual.estado) vibrar("exito");
      fijarIncidente(inc);
    });
    s.on("chat:mensaje", ({ incidenteId, mensaje }) => {
      const actual = incRef.current;
      if (!actual || incidenteId !== actual.id || actual.mensajes.some((m) => m.id === mensaje.id)) return;
      if (mensaje.de === "bomberos") vibrar("ligero");
      fijarIncidente({ ...actual, mensajes: [...actual.mensajes, mensaje] });
    });

    pedir("/api/config").then((r) => r.json()).then((cfg) => { campusRef.current = cfg.campus; }).catch(() => {});

    return () => { clearTimeout(temporizador); s.disconnect(); };
  }, [deviceId, fijarIncidente, procesarCola]);

  // 4) Geolocalización (el GPS no necesita internet)
  const publicarUbicacion = useCallback((u) => {
    ubicRef.current = u;
    setUbicacion(u);
    const ahora = Date.now();
    if (ahora - ultimoEnvio.current > 3000) {
      ultimoEnvio.current = ahora;
      socketRef.current?.emit("ubicacion", u);
    }
  }, []);

  const permisoConcedido = useCallback(async () => {
    try {
      return (await Location.getForegroundPermissionsAsync()).status === "granted";
    } catch {
      return false;
    }
  }, []);

  const iniciarGPS = useCallback(async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") throw new Error("Permiso de ubicación denegado. Actívalo en los ajustes del teléfono.");
    clearInterval(simRef.current);
    setSimulada(false);
    watchRef.current?.remove();
    watchRef.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.High, timeInterval: 3000, distanceInterval: 1 },
      (p) => publicarUbicacion({ lat: p.coords.latitude, lng: p.coords.longitude, precision: p.coords.accuracy ?? null })
    );
  }, [publicarUbicacion]);

  const iniciarSimulacion = useCallback(() => {
    watchRef.current?.remove();
    setSimulada(true);
    const c = campusRef.current;
    const base = { lat: c.lat + (Math.random() - 0.5) * 0.0015, lng: c.lng + (Math.random() - 0.5) * 0.0015 };
    publicarUbicacion({ ...base, precision: 10 });
    clearInterval(simRef.current);
    simRef.current = setInterval(() => {
      base.lat += (Math.random() - 0.5) * 0.00008;
      base.lng += (Math.random() - 0.5) * 0.00008;
      publicarUbicacion({ ...base, precision: 10 });
    }, 5000);
  }, [publicarUbicacion]);

  useEffect(() => () => { watchRef.current?.remove(); clearInterval(simRef.current); }, []);

  // 5) Acciones
  const guardarPerfil = useCallback(async (datos) => {
    const p = { ...PERFIL_VACIO, ...datos, registrado: true };
    perfilRef.current = p;
    setPerfil(p);
    await AsyncStorage.setItem("sos_perfil", JSON.stringify(p)).catch(() => {});
    try {
      await subirPerfil(deviceId, p);
      return { sincronizado: true };
    } catch {
      return { sincronizado: false };
    }
  }, [deviceId]);

  // Intenta enviar; si no hay conexión, deja la emergencia en la cola con el análisis local
  const enviar = useCallback(async (tipo, datos, analisisLocal, textoSistema) => {
    const ruta = tipo === "sos" ? "/api/panico" : "/api/incidentes";
    const perfilEnvio = perfilRef.current.registrado ? perfilRef.current : undefined;
    try {
      const r = await postJSON(ruta, { deviceId, ...datos, ubicacion: ubicRef.current, perfil: perfilEnvio });
      const inc = await r.json();
      if (!r.ok) throw new ErrorServidor(inc.error || "No se pudo enviar.");
      if (!inc.analisis) inc.analisis = analisisLocal;
      fijarIncidente(inc);
      socketRef.current?.emit("incidente:unirse", inc.id);
      vibrar(tipo === "sos" ? "alerta" : "exito");
      return inc;
    } catch (err) {
      if (err instanceof ErrorServidor) throw err;
      // Sin conexión: emergencia local con la recomendación calculada en el teléfono
      const idLocal = nuevoId("LOCAL");
      const local = {
        id: idLocal,
        local: true,
        tipo: tipo === "sos" ? "panico" : "reporte",
        estado: "pendiente",
        creadoEn: Date.now(),
        asignado: null,
        analisis: analisisLocal,
        mensajes: [{ id: idLocal + "-m", de: "sistema", texto: textoSistema, ts: Date.now() }],
      };
      guardarCola([...colaRef.current, { idLocal, tipo, datos: { ...datos, ubicacion: ubicRef.current }, creadoEn: Date.now() }]);
      fijarIncidente(local);
      vibrar("alerta");
      return local;
    }
  }, [deviceId, fijarIncidente, guardarCola]);

  const enviarReporte = useCallback((datos) => {
    const p = perfilRef.current;
    const analisis = {
      ...analizarEmergencia({
        descripcion: datos.descripcion,
        rol: datos.rol,
        // La edad que importa es la del afectado (si quien reporta es observador, la que indicó)
        edad: datos.rol === "afectado" ? datos.edad : datos.afectado?.edad,
        perfil: p.registrado && datos.rol === "afectado" ? p : undefined,
      }),
      ts: Date.now(),
    };
    return enviar("reporte", datos, analisis,
      "Sin conexión con la central. Sigue las recomendaciones de la IA; tu reporte se enviará automáticamente en cuanto vuelva la señal.");
  }, [enviar]);

  const enviarSOS = useCallback(() => {
    const p = perfilRef.current;
    const analisis = { ...analisisSOS(p.registrado ? p : null), ts: Date.now() };
    return enviar("sos", {}, analisis,
      "Sin conexión con la central. Tu alerta SOS se enviará automáticamente en cuanto vuelva la señal. Si puedes, llama o envía un SMS a los Bomberos Universitarios.");
  }, [enviar]);

  const enviarMensaje = useCallback((texto) => {
    const t = texto.trim();
    const actual = incRef.current;
    if (!t || !actual) return;
    if (actual.local) {
      // Sin conexión: el mensaje se guarda y se envía cuando la alerta llegue a la central
      fijarIncidente({ ...actual, mensajes: [...actual.mensajes, { id: nuevoId("m"), de: "usuario", texto: t, ts: Date.now() }] });
      return;
    }
    socketRef.current?.emit("chat:enviar", { incidenteId: actual.id, texto: t });
  }, [fijarIncidente]);

  const cerrarIncidente = useCallback(() => fijarIncidente(null), [fijarIncidente]);

  return (
    <Contexto.Provider
      value={{
        listo: Boolean(deviceId) && perfilCargado, conectado, sinSenal, pendientes, ubicacion, simulada, incidente, perfil,
        permisoConcedido, iniciarGPS, iniciarSimulacion, guardarPerfil,
        enviarReporte, enviarSOS, enviarMensaje, cerrarIncidente, reintentar: procesarCola,
      }}
    >
      {children}
    </Contexto.Provider>
  );
}
