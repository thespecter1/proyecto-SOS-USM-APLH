# SOS USM – App móvil (React Native)

App móvil de la comunidad de la Universidad Santa María para reportar emergencias. Está construida con **React Native** y **Expo** (SDK 58) y se conecta al servidor Node.js de la carpeta superior (`../server.js`).

## Tecnologías

| Tecnología | Uso |
|---|---|
| **React Native 0.88** + **React 19** | Interfaz nativa para Android e iOS |
| **Expo SDK 58** | Herramientas de desarrollo, compilación y módulos nativos |
| **Expo Router** | Navegación entre pantallas (rutas en `src/app/`) |
| **expo-location** | GPS en tiempo real |
| **socket.io-client** | Alertas, estado y chat en tiempo real con la central |
| **expo-haptics** | Vibración al enviar alertas y al recibir respuestas |
| **AsyncStorage** | Guarda el identificador del dispositivo, el perfil y la emergencia activa |
| **react-native-svg** + **expo-linear-gradient** | Íconos, logo, anillo de progreso del SOS y degradados |

## Estructura

```
src/
  app/                      Pantallas (Expo Router)
    _layout.js              Raíz: fuentes, proveedor de estado y navegación
    index.js                Bienvenida y permiso de ubicación
    elegir-registro.js      Tras el GPS: "Registrarme ahora" o "Más tarde" (se ofrece cada vez que se abre la app sin registro)
    registro.js             Registro del perfil (datos personales, médicos y contacto de emergencia)
    inicio.js               Dos opciones: emergencia normal (2/4) y alta prioridad (1/4, roja)
    reporte.js              Formulario: tipo de usuario, nombre, edad, rol y descripción
    alta-prioridad.js       Advertencia, confirmación y botón SOS (mantener 3 s)
    emergencia.js           Estado en vivo, recomendaciones de la IA y chat
  componentes/
    BotonSOS.js             Botón SOS con anillo de progreso animado
    Icono.js                Íconos SVG y logo
    UI.js                   Cabecera, chip GPS y botones
  estado/SOSContext.js      Estado global: perfil, GPS, Socket.IO, cola sin conexión y emergencia activa
  ia/motorIA.js             IA en el teléfono: Naive Bayes + sistema experto (funciona sin internet)
  componentes/ContactoDirecto.js  Llamada y SMS con ubicación a los bomberos (sin datos móviles)
  tema.js                   Colores, fuentes y dirección del servidor
```

## Cómo probarla en tu teléfono (Expo Go)

1. **Inicia el servidor** en tu computadora, desde la carpeta raíz del proyecto:
   ```bash
   npm install
   npm start
   ```
2. **Averigua la IP local** de tu computadora (por ejemplo `192.168.1.100`). El teléfono y la computadora deben estar en la **misma red Wi-Fi**.
3. **Configura esa IP** en `app.json`, en `expo.extra.servidor`: `"http://192.168.1.100:3000"`. También puedes usar la variable `EXPO_PUBLIC_SERVIDOR`.
4. **Instala dependencias y arranca la app:**
   ```bash
   cd app-movil
   npm install
   npx expo start
   ```
5. Instala **Expo Go** (Play Store o App Store) y escanea el código QR que aparece en la terminal.
6. En la computadora, abre la central: `http://localhost:3000/bomberos/` (PIN `usm2026`).

> A diferencia de la versión web, la app nativa **no necesita HTTPS** para usar el GPS.

## Generar el APK (Android)

Con una cuenta gratuita de Expo:
```bash
npx eas-cli@latest login
npx eas-cli@latest build -p android --profile preview
```
EAS compila en la nube y entrega un enlace para descargar el `.apk`. La app ya permite conexiones `http://` al servidor de la red local (`usesCleartextTraffic`).

## Funcionamiento sin internet

La app depende lo menos posible de la conexión:

| Función | ¿Necesita internet? |
|---|---|
| GPS | No (usa el satélite) |
| **Recomendación de la IA** | **No:** se calcula en el teléfono (`src/ia/motorIA.js`) |
| Registro del perfil | No (se guarda en el teléfono y se sincroniza después) |
| Enviar reporte o alerta SOS | Si no hay conexión, **se guarda en una cola y se envía sola** al volver la señal |
| Chat | Los mensajes escritos sin conexión se envían al reconectar |
| Llamar o SMS a la central | No (usa la red telefónica) |

### La IA del teléfono
- **Clasificador Naive Bayes multinomial**: aprendizaje automático entrenado con frases de ejemplo en español venezolano, más un *stemmer* para el español. Identifica 13 tipos de emergencia: incendio, cardíaca, respiratoria, pérdida de conocimiento, trauma, quemadura, alergia, gas o químicos, estructural, eléctrica, seguridad, malestar y crisis emocional.
- **Sistema experto** (reglas):
  - Define la gravedad con señales de riesgo vital ("no respira", "mucha sangre", "arma"…) y con la edad.
  - Detecta un **posible paro cardiorrespiratorio** (persona inconsciente que no respira) y prioriza la RCP.
  - Da recomendaciones distintas para el **afectado** y el **observador**.
  - Las **personaliza con la ficha médica**: asma, diabetes, alergias, problemas cardíacos.
- **Mismo motor en el servidor:** el servidor usa este mismo archivo, así que hay una sola base de conocimiento. Con internet, Claude refina después el análisis.
- **Evaluación:** `node scripts/evaluar-ia.js`, desde la carpeta raíz, mide la exactitud con 30 frases que no están en el entrenamiento. Resultado actual: **96,7 %**, con unos **0,2 ms** por análisis.

### Teléfono de la central
En `app.json` → `expo.extra.telefonoBomberos` pon el número real de los Bomberos Universitarios. Es el que usan los botones **Llamar** y **SMS con ubicación** que aparecen cuando no hay conexión.

## Registro del perfil
Después de dar el permiso de ubicación, la app ofrece **"Registrarme ahora"** o **"Más tarde"**. Mientras la persona no se registre, esa pregunta aparece cada vez que abre la app. El **registro** que se llena una sola vez, en un momento de calma. Incluye:
- **Datos personales:** tipo de miembro de la comunidad, nombre, cédula, edad, teléfono y carrera o área.
- **Información médica (opcional):** tipo de sangre, condiciones médicas, alergias y medicamentos.
- **Contacto de emergencia:** nombre, parentesco y teléfono.
- **Autorización** para compartir los datos con los Bomberos Universitarios, solo cuando la persona envía una alerta.

Con el registro hecho:
- La **alerta SOS** se envía con un solo gesto y la central recibe la ficha completa.
- Si quien reporta es **observador**, se pregunta si conoce al afectado. Si lo conoce, se piden su nombre, edad y cédula para buscar su ficha, que **solo reciben los bomberos**.
- El **reporte normal** solo pregunta **quién necesita ayuda** (la persona o alguien más) y **qué pasó**. Si la persona no está registrada, también pide tipo de usuario, nombre y edad.
- La IA tiene en cuenta los antecedentes médicos cuando el afectado es la propia persona.

El registro se guarda en el teléfono (AsyncStorage) y en el servidor (`data/perfiles.json`). Se puede editar desde **Mi registro** en la pantalla de inicio, y se puede omitir con "Completar más tarde".

## Notas
- Si se niega el permiso de ubicación, la app ofrece un **modo demostración** que simula la ubicación dentro del campus.
- Si la app se cierra durante una emergencia, al volver a abrirla recupera la emergencia activa y su chat.
- La ubicación se comparte solo mientras la app está abierta. El rastreo en segundo plano se puede agregar con `Location.startLocationUpdatesAsync`, pero requiere una compilación de desarrollo y el permiso de ubicación "siempre".
